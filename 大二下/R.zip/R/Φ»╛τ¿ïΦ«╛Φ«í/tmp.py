import cairosvg

def convert_svg_to_pdf(input_path, output_path):
    """
    将 SVG 文件转换为 PDF 文件
    
    参数:
        input_path: 输入 SVG 文件路径
        output_path: 输出 PDF 文件路径
    """
    cairosvg.svg2pdf(url=input_path, write_to=output_path)
    print(f"成功将 {input_path} 转换为 {output_path}")

# 使用示例
if __name__ == "__main__":
    input_file = "model.svg"
    output_file = "model.pdf"
    convert_svg_to_pdf(input_file, output_file)
