```python
# Try reloading the newly uploaded file using a suitable encoding to fix any garbled text
file_path = Path("/mnt/data/mj4stu 3.R")

# Attempt reading using a common Chinese-compatible encoding (GB18030)
with file_path.open("r", encoding="gb18030") as f:
    content_fixed = f.read()

# Show a sample of the fixed content
content_fixed[:1000]
```

# 函数`lm()`

`lm()` 是 R 语言中用于拟合线性回归模型的一个非常重要的函数。它属于基础包 `stats`，因此无需额外安装即可使用。

### 基本语法
```r
lm(formula, data, subset, weights, na.action, method = "qr", model = TRUE, x = FALSE, y = FALSE, qr = TRUE, ...)
```

### 参数说明
- **formula**: 模型公式，如 `y ~ x1 + x2` 表示因变量 `y` 和自变量 `x1`, `x2` 的关系。
- **data**: 包含变量的数据框。
- **subset**: 可选参数，指定用于拟合的观测子集。
- **weights**: 可选参数，指定加权最小二乘的权重。
- **na.action**: 处理缺失值的方法，默认为 `na.omit`（删除缺失值）。
- **method**: 计算方法，默认为 `"qr"`（QR 分解）。
- **model, x, y, qr**: 是否返回模型矩阵、设计矩阵、响应向量和 QR 分解结果。

### 返回值
`lm()` 函数返回一个包含模型信息的对象，包括系数、残差、拟合值等。

---

### 示例

假设你有一个数据框 `df`，其中包含因变量 `y` 和自变量 `x1`, `x2`：

```r
# 创建示例数据
set.seed(123)
df <- data.frame(
  y = rnorm(100),
  x1 = rnorm(100),
  x2 = rnorm(100)
)

# 使用 lm() 拟合线性模型
model <- lm(y ~ x1 + x2, data = df)

# 查看模型摘要
summary(model)
```

### 解释
- `y ~ x1 + x2`: 表示模型形式为 $ y = \beta_0 + \beta_1 x_1 + \beta_2 x_2 + \epsilon $。
- `summary(model)`: 输出模型的详细信息，包括系数估计值、标准误、t 值、p 值以及 R² 等统计指标。

---

### 常见用法
1. **简单线性回归**：
   ```r
   model <- lm(y ~ x, data = df)
   ```

2. **多元线性回归**：
   ```r
   model <- lm(y ~ x1 + x2 + x3, data = df)
   ```

3. **带交互项的模型**：
   ```r
   model <- lm(y ~ x1 * x2, data = df)  # 包括主效应和交互效应
   ```

4. **多项式回归**：
   ```r
   model <- lm(y ~ poly(x, degree = 2), data = df)  # 二次多项式
   ```

5. **排除截距项**：
   ```r
   model <- lm(y ~ x - 1, data = df)  # 强制通过原点
   ```

---

### 提取模型信息
- **系数**：`coef(model)`
- **残差**：`residuals(model)`
- **拟合值**：`fitted(model)`
- **预测新数据**：`predict(model, newdata = df_new)`

---

### 注意事项
- `lm()` 默认使用最小二乘法 (OLS) 进行拟合。
- 如果数据中存在多重共线性或奇异矩阵问题，可以通过检查 `summary()` 中的警告信息来识别。
- 对于大规模数据集，可以考虑使用更高效的算法或包（如 `biglm` 或 `glmnet`）。

# `uniform` 均匀分布

在 R 语言中，**均匀分布（Uniform Distribution）** 是一种连续型概率分布，其特点是随机变量在某个区间 $[a, b]$ 内的每个值出现的概率是相等的。

---

### 均匀分布的基本概念

- **密度函数**：
  $$
  f(x) = \frac{1}{b - a}, \quad a \leq x \leq b
  $$

- **分布函数**：
  $$
  F(x) = \frac{x - a}{b - a}, \quad a \leq x \leq b
  $$

- **期望值**：
  $$
  E(X) = \frac{a + b}{2}
  $$

- **方差**：
  $$
  Var(X) = \frac{(b - a)^2}{12}
  $$

---

### R 中与均匀分布相关的函数

R 提供了以下内置函数来处理均匀分布：

| 函数名 | 功能描述 |
|--------|----------|
| `dunif(x, min = 0, max = 1)` | 概率密度函数（PDF） |
| `punif(q, min = 0, max = 1)` | 累积分布函数（CDF） |
| `qunif(p, min = 0, max = 1)` | 分位数函数（inverse CDF） |
| `runif(n, min = 0, max = 1)` | 随机数生成 |

#### 示例代码

```r
# 设置参数
a <- 2   # 最小值
b <- 5   # 最大值

# 密度函数 dunif()
x <- seq(0, 6, by = 0.1)
plot(x, dunif(x, min = a, max = b), type = "l", col = "blue", lwd = 2,
     main = "Uniform PDF (a=2, b=5)", ylab = "Density")

# 累积分布函数 punif()
plot(x, punif(x, min = a, max = b), type = "l", col = "red", lwd = 2,
     main = "Uniform CDF (a=2, b=5)", ylab = "Probability")

# 分位数函数 qunif()
p <- seq(0, 1, by = 0.01)
plot(p, qunif(p, min = a, max = b), type = "l", col = "green", lwd = 2,
     main = "Uniform Quantile Function", ylab = "Quantiles")

# 随机数生成 runif()
set.seed(123)  # 设置随机种子以保证可重复性
random_values <- runif(1000, min = a, max = b)
hist(random_values, breaks = 30, col = "lightblue",
     main = "Histogram of Uniform Random Numbers", xlab = "Value")
```

---

### 应用场景

1. **模拟实验**：生成在某一范围内均匀分布的随机数用于蒙特卡洛模拟。
2. **密码学**：某些加密算法需要使用均匀分布的随机数作为密钥或初始向量。
3. **统计抽样**：在简单随机抽样中，样本点落在区间内的概率是均匀的。

---

### 注意事项

- 如果没有指定 `min` 和 `max`，默认为标准均匀分布 $ U(0,1) $。
- 在实际应用中，如果需要将均匀分布转换为其他分布（如正态分布、指数分布），可以使用**逆变换法**或其他方法。