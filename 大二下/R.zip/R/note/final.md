# 数据框

`cbind()`可以合并向量，`rbind()`可以合并两个数据框。

# 计算收益率

```r
# 加载必要的包
library(xts)

# 创建示例数据（股票收盘价）
dates <- seq(as.Date("2023-01-01"), by = "day", length.out = 10)
prices <- c(100, 102, 105, 103, 108, 110, 109, 112, 115, 113)

# 转换为xts对象（可选，但推荐用于时间序列分析）
price_series <- xts(prices, order.by = dates)
colnames(price_series) <- "Close"

# 方法1：使用diff(log())计算对数收益率
log_returns <- diff(log(price_series))

# 方法2：使用log() + diff()分步计算
log_prices <- log(price_series)
log_returns_alt <- diff(log_prices)

# 方法3：使用核心函数计算（等价于diff(log())）
log_returns_manual <- log(price_series / lag(price_series, 1))

# 方法4：使用periodReturn()函数（xts包提供）
library(PerformanceAnalytics)
returns_period <- periodReturn(price_series, period = "daily", type = "log")

# 查看结果
head(cbind(price_series, log_returns), 5)

# 可视化收益率
plot(log_returns, main = "Daily Log Returns", ylab = "Return", type = "h")
abline(h = 0, col = "red", lty = 2)
    
```

大作业

```r
boll <- function(x, date, N, alpha){
    n <- length(x),
    for(i in 1:n){
        ma <- mean(),
        up <- ma + alpha * sd(x),
        down <- ma - alpha * sd(x)
    }
}
```
