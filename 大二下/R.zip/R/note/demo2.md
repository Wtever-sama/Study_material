# debug()
在 R 语言中，`debug()` 是一个非常实用的调试工具，用于**对指定函数开启交互式调试模式**。当你调用被 `debug()` 标记的函数时，R 会在函数执行前自动进入调试环境（类似插入了 `browser()`），允许你逐行查看代码、检查变量、单步执行等。

---

## ✅ 基本语法

```r
debug(function_name)
```

- `function_name`：你要调试的函数名。
- 调试开启后，每次调用该函数都会进入调试模式。

### 🚫 关闭调试

```r
undebug(function_name)
```

---

## 🧪 示例演示

假设我们有一个自定义函数 `statmy()`：

```r
statmy <- function(x, plot.it = FALSE) {
  if (!is.vector(x)) stop("Input must be a vector.")
  mean_x <- mean(x)
  sd_x <- sd(x)
  if (plot.it) plot(density(x)) # (plot.it)属于逻辑变量，plot(density(x))是绘制x的概率密度函数进行非参数估计
  list(mean = mean_x, sd = sd_x)
}
```

### 1. 启用调试

```r
debug(statmy)
```

### 2. 调用函数，触发调试

```r
data.sim.1 <- rnorm(1000)
statmy(x = data.sim.1, plot.it = TRUE)
```

此时你会看到如下提示：

```
debugging in: statmy(x = data.sim.1, plot.it = TRUE)
debug: {
    if (!is.vector(x)) stop("Input must be a vector.")
    mean_x <- mean(x)
    sd_x <- sd(x)
    if (plot.it) plot(density(x))
    list(mean = mean_x, sd = sd_x)
}
Browse[1]>
```

### 3. 在调试环境中可用命令

| 命令 | 功能 |
|------|------|
| `n`| 执行下一行代码（Next） |
| `s` | Step into（进入当前行调用的函数内部） |
| `c` | Continue（继续执行直到函数结束或遇到下一个断点） |
| `Q` | Quit（退出调试器并停止函数执行） |
| `ls()` | 查看当前环境中的变量 |
| `print(var)` 或直接输入变量名 | 查看变量值 |

---

## 🔍 结合错误调试使用更强大

你可以配合 `recover()` 和 `options(error = recover)` 来增强调试体验：

```r
options(error = recover)  # 出错时弹出调用栈供选择调试层级
debug(statmy)             # 开启 statmy 的调试模式
```

这样即使程序报错，也能回溯到出错的具体函数上下文进行排查。

---

## 🛠️ 实战建议

| 场景 | 方法 |
|------|------|
| 调试某个函数的所有调用 | 使用 `debug(function_name)` |
| 只调试一次函数调用 | 使用 `debugonce(function_name)` |
| 关闭调试 | 使用 `undebug(function_name)` |
| 自动进入错误现场 | 设置 `options(error = recover)` |
| 查看出错堆栈 | 使用 `traceback()` |

---

## 📌 小贴士

- `debug()` 不适用于 S3/S4 泛型函数（如 [plot()](file:///Users/wtsama/Documents/code/Wtever-repository/python/week10/abstract_visualize.py#L14-L15)、`summary()` 等），应使用 `debugonce()` 或 `trace()`；
- 如果你只想调试某一次调用，推荐使用 `debugonce()`；
- 调试结束后务必关闭调试，避免影响性能；
- 配合 `browser()` 插入特定位置，可实现局部精细调试。

---

## ✅ 总结对比

| 函数 | 作用 | 是否自动进入调试 | 是否需手动设置 |
|------|------|------------------|----------------|
| `debug()` | 永久启用函数调试 | ✅ | ✅ |
| `debugonce()` | 下次调用后自动取消调试 | ✅ | ✅ |
| `browser()` | 手动插入代码中触发调试 | ✅ | ✅ |
| `recover()` | 出错时弹出调用栈供选择调试层级 | ❌ | ✅（配合 `options()`） |

---

如需进一步了解，可在 R 控制台输入：

```r
?debug
?undebug
?debugonce
?recover
?options
```





# browser()
`browser()` 是 R 语言中用于调试的一个非常有用的函数。当你在代码的某个位置插入 `browser()`，程序执行到该点时会进入交互式调试模式（类似于断点），你可以在此检查变量、单步执行代码或修改代码逻辑。

---

## ✅ 基本用法

```r
browser()
```

将该函数插入你希望暂停执行的位置：

```r
my_function <- function(x) {
  browser()  # 程序运行到这里会暂停
  y <- x + 1
  return(y)
}

my_function(5)
```

一旦执行到 `browser()`，控制台会显示如下提示：

```
Called from: my_function(5)
Browse[1]>
```

此时你可以输入以下命令进行调试：

---

## 🧪 可用调试命令

| 命令 | 说明 |
|------|------|
| [n](file:///Users/wtsama/Documents/code/Wtever-repository/python/4.py#L13-L13) | 执行下一行代码（Next） |
| `s` | 进入当前行的函数内部（Step into） |
| `c` | 继续执行直到下一个 `browser()` 或结束（Continue） |
| `Q` | 停止调试并退出函数（Quit） |
| `where` | 显示当前调用堆栈 |
| `ls()` | 查看当前环境中所有变量 |
| `print(var)` 或直接输入变量名 | 查看变量值 |

---

## 🛠️ 示例场景

### 场景：调试自定义函数

```r
statmy <- function(x, plot.it = FALSE) {
  if (!is.vector(x)) stop("Input must be a vector.")
  mean_x <- mean(x)
  browser()  # 调试点
  sd_x <- sd(x)
  if (plot.it) plot(density(x))
  list(mean = mean_x, sd = sd_x)
}
```

运行时：

```r
data.sim.2 <- matrix(rnorm(2000), nrow=2)
statmy(x = data.sim.2, plot.it = TRUE)
```

当执行到 `browser()` 时，你会进入调试环境，可以检查 `x` 的结构：

```r
Browse[1]> class(x)
[1] "matrix" "array"
Browse[1]> dim(x)
[1] 2 1000
```

从而确认问题出在 `x` 不是向量，符合错误提示。

---

## 🔍 和 `debug()` 的区别

- `debug(function_name)`：为整个函数启用调试，每次调用都会进入 `browser()` 模式。
- `browser()`：手动插入，仅在特定位置触发一次调试。

---

## ✅ 最佳实践

- 在复杂函数的关键逻辑前插入 `browser()`，便于逐行验证中间结果。
- 使用 `if (FALSE) browser()` 可以快速开关调试。
- 配合 `recover()` 使用可自动进入错误现场调试。

```r
options(error = recover)
```

---

如需进一步了解，可在 R 控制台输入：

```r
?browser
```




# recover()
---
在 R 语言中，`recover()` 是一个非常有用的调试工具，它可以与 `options(error = recover)` 配合使用，在程序出现错误时自动进入调试环境，方便你检查出错时的调用栈和变量状态。

---

## ✅ 基本用法

### 1. 设置全局错误恢复机制：

```r
options(error = recover)
```

一旦设置了这个选项，当你的代码运行出错时，R 不会直接报错退出，而是弹出一个调用栈（call stack）列表，让你选择进入哪个函数层级进行调试。

---

### 🧪 示例






# sd()
## 标准差（Standard Deviation）
```r
sd(x, na.rm = FALSE)
```
   - `sd()` 函数用于计算给定向量 `x` 的标准差。
   - `na.rm` 参数用于指定是否移除 NA 值。默认为 FALSE。若设为 TRUE，则忽略缺失值进行计算
  

---
# scale()
```r
scale(x, center = TRUE, scale = TRUE)
```
`scale()` 函数用于将向量 `x` 标准化，即将数据缩放到一个标准正态分布。
  - `center` 参数用于指定是否将向量减去均值。默认为 TRUE。
  - `scale` 参数用于指定是否将向量除以标准差。默认为 TRUE。
手动编辑：`row_zcores <- function(x) (x - mean(x)) / sd(x)`

---
# apply() vs lapply() vs sapply()
`apply()`、`lapply()` 和 `sapply()` 是 R 语言中用于批量操作数组或列表的工具函数。
在 R 语言中，`lapply`、`apply` 和 `sapply` 是常用的循环替代函数，它们都用于对数据结构执行重复操作，但在应用对象、返回值和使用场景上有所不同。以下是它们的核心区别和使用示例：


### **1. `lapply()`：列表应用（List Apply）**
- **应用对象**：主要用于列表、向量或数据框。
- **返回值**：始终返回**列表**，即使输入是向量或数据框。
- **特点**：对每个元素执行函数，结果长度与输入相同。

**示例**：
```r
# 对列表每个元素加 1
x <- list(a = 1:3, b = 4:6)
result <- lapply(x, function(y) y + 1)
print(result)
# $a
# [1] 2 3 4
# $b
# [1] 5 6 7

# 对向量使用（自动转换为列表处理）
y <- 1:3
result <- lapply(y, function(z) z^2)
print(result)
# [[1]]
# [1] 1
# [[2]]
# [1] 4
# [[3]]
# [1] 9
```


### **2. `apply()`：数组应用（Array Apply）**
- **应用对象**：主要用于矩阵、数组或数据框。
- **返回值**：返回向量、数组或列表，取决于结果是否能被简化为更高维结构。
- **特点**：按行（`MARGIN = 1`）或列（`MARGIN = 2`）应用函数。

**示例**：
```r
# 对矩阵每列求和（MARGIN = 2）
x <- matrix(1:6, nrow = 2)
result <- apply(x, 2, sum)
print(result)
# [1]  3 7 11

# 对矩阵每行求均值（MARGIN = 1）
result <- apply(x, 1, mean)
print(result)
# [1] 3 4

# 复杂函数示例：每行标准化
result <- apply(x, 1, function(row) (row - mean(row)) / sd(row))
print(result)
#           [,1]      [,2]
# [1,] -1.224745  1.224745
# [2,] -1.224745  1.224745
```


### **3. `sapply()`：简化版应用（Simplified Apply）**
- **应用对象**：同 `lapply`（列表、向量、数据框）。
- **返回值**：尝试将结果**简化为向量、矩阵或数组**，若无法简化则返回列表（类似 `lapply`）。
- **特点**：自动简化结果，代码更简洁。

**示例**：
```r
# 对向量每个元素平方（返回向量）
x <- 1:3
result <- sapply(x, function(y) y^2)
print(result)
# [1] 1 4 9

# 结果无法简化时返回列表
x <- list(a = 1:2, b = 3:5)
result <- sapply(x, function(y) y[1])
print(result)
# a b 
# 1 3 
result <- sapply(x, function(y) y[3])
print(result)
# a  b 
# NA  5
```


### **核心区别总结**
| 函数   | 输入类型       | 返回类型               | 自动简化？ | 典型场景                     |
|--------|----------------|------------------------|------------|------------------------------|
| `lapply` | 列表、向量、数据框 | **列表**               | 否         | 需要列表输出时              |
| `apply`  | 矩阵、数组、数据框 | 向量、数组、列表       | 视情况     | 按行/列处理矩阵数据          |
| `sapply` | 列表、向量、数据框 | 向量、矩阵、数组或列表 | 是         | 结果可简化为基础类型时      |


### **选择建议**
1. **优先用 `sapply`**：当你希望结果是向量或矩阵时（代码更简洁）。
2. **用 `lapply`**：当需要确保输出是列表时（例如每个元素返回多个值）。
3. **用 `apply`**：处理矩阵或数组的行/列操作时。


### **进阶示例**
#### 1. 使用 `lapply` 处理数据框列
```r
df <- data.frame(a = 1:3, b = 4:6)
result <- lapply(df, function(col) col * 2)
print(result)
# $a
# [1] 2 4 6
# $b
# [1]  8 10 12
```

#### 2. 使用 `apply` 对矩阵每行执行复杂操作
```r
x <- matrix(1:9, nrow = 3)
result <- apply(x, 1, function(row) c(min = min(row), max = max(row)))
print(result)
#      [,1] [,2] [,3]
# min    1    2    3
# max    3    6    9
```

#### 3. 使用 `sapply` 计算多个统计量
```r
x <- list(a = rnorm(100), b = rnorm(100, mean = 5))
result <- sapply(x, function(y) c(mean = mean(y), sd = sd(y)))
print(result)
#           a        b
# mean 0.0123 5.045678
# sd   0.9876 0.998765
```


### **注意事项**
- **缺失值**：处理含 `NA` 的数据时，需在函数中添加 `na.rm = TRUE`。
- **效率**：`apply` 对矩阵的操作通常比显式循环快，但 `lapply`/`sapply` 对大型数据可能较慢（考虑使用 `vapply` 或 `purrr` 包）。
- **简化规则**：`sapply` 简化规则较复杂，若结果长度不一致则返回列表。

如果需要进一步示例或有特定场景需求，请告诉我！