偏度（Skewness）是统计学中衡量数据分布不对称性的指标。其公式如下：

### 偏度的计算公式：
对于一组数据 $ x_1, x_2, \ldots, x_n $，偏度定义为：

$$
\text{Skewness} = \frac{n}{(n-1)(n-2)} \sum_{i=1}^n \left( \frac{x_i - \bar{x}}{s} \right)^3
$$

其中：
- $ n $：样本数量；
- $ \bar{x} $：样本均值；
- $ s $：样本标准差。

在 R 中，可以使用 `moments` 包中的 `skewness()` 函数来直接计算偏度。例如：

```r
library(moments)

# 示例数据
data <- c(1, 2, 3, 4, 5)

# 计算偏度
skewness_value <- skewness(data)
print(skewness_value)
```

### 偏度的意义：
- **偏度 = 0**：表示数据分布对称（如正态分布）；
- **偏度 > 0**：表示数据右偏（长尾在右侧）；
- **偏度 < 0**：表示数据左偏（长尾在左侧）。