### 核心考点提取（按重要性排序）

---

#### **1. 多元回归分析** ***  
- **模型表示**：  
  \[ Y = \beta_0 + \beta_1 X_1 + \cdots + \beta_k X_k + \varepsilon \]  
  - 假设：\(\varepsilon \sim N(0, \sigma^2)\)，条件期望 \(E(Y|X) = X\beta\)。  
- **参数估计**：  
  - OLS估计：\(\hat{\beta} = (X'X)^{-1}X'Y\)，\(\hat{\sigma}^2 = \frac{RSS}{n-k-1}\)。  
- **检验**：  
  - 整体显著性（F检验）：\(H_0: \beta_1 = \cdots = \beta_k = 0\)。  
  - 单变量显著性（t检验）：\(H_0: \beta_j = 0\)。  
- **诊断**：  
  - 残差分析（帽子矩阵 \(H = X(X'X)^{-1}X'\)）。  
  - 多重共线性（VIF > 10 严重）。  

---

#### **2. 逐步回归分析** ***  
- **原理**：变量“有进有出”，筛选重要变量。  
- **筛选准则**：  
  - F检验（最大F值进入，最小F值退出）。  
  - AIC准则（越小越好，R默认使用）。  
- **R函数**：`step()`。  

---

#### **3. 二元选择模型（Logit/Probit）** ***  
- **模型**：  
  - 潜变量：\(Y_i^* = \alpha + \beta X_i + \varepsilon_i\)，\(Y_i = I(Y_i^* > 0)\)。  
  - 概率变换：\(p_i = F(\alpha + \beta X_i)\)，\(F\)为Logit/Probit/Extreme分布。  
- **Logit vs Probit**：  
  - Logit：\(F(x) = e^x/(1+e^x)\)，尾部更厚。  
  - Probit：标准正态CDF，拐点在(0, 0.5)。  

---

#### **4. 广义线性模型（GLM）** **  
- **三要素**：  
  1. 随机成分（指数分布族，如二项/Poisson）。  
  2. 系统成分（线性预测 \(\eta = X\beta\)）。  
  3. 连接函数（如Logit、Identity）。  
- **R函数**：`glm(formula, family=binomial(link="logit"), data)`。  

---

#### **5. 时间序列分析（ARMA/VAR）** **  
- **ARMA模型**：  
  - 表示：\(y_t = \phi_1 y_{t-1} + \cdots + \phi_p y_{t-p} + \epsilon_t + \theta_1 \epsilon_{t-1} + \cdots + \theta_q \epsilon_{t-q}\)。  
  - 定阶：AIC/BIC准则。  
- **VAR模型**：  
  - 表示：\(Y_t = \sum_{j=1}^p \Phi_j Y_{t-j} + \varepsilon_t\)。  
  - 脉冲响应：\(\partial Y_{t+s}/\partial \varepsilon_t\)。  

---

#### **6. 优化理论** *  
- **线性规划**：  
  - 单纯形法求解，R包 `Rglpk`。  
- **非线性规划**：  
  - K-T条件（必要非充分），R函数 `optim()`。  
- **二次规划**：目标函数为二次型，约束为线性。  

---

### 次要考点  
- **聚类分析**：距离度量（欧式距离）、标准化方法。  
- **因子分析**：降维，公因子方差贡献率。  
- **计数数据模型**：Poisson回归、零膨胀模型。  

---

### 工具与R包速查  
| 任务         | R包/函数                      |
| ------------ | ----------------------------- |
| 多元回归     | `stats::lm()`, `summary()`    |
| 逐步回归     | `step()`                      |
| 二元选择模型 | `glm(family=binomial)`        |
| 时间序列     | `arima()`, `vars::VAR()`      |
| 优化问题     | `optim()`, `Rglpk_solve_LP()` |

**注**：标***为高频核心考点，需重点掌握模型表示、估计方法与R实现。