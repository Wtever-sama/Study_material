# %%
##### 统计描述函数 + 正态性检验 ####

## 1. 统计描述和正态性检验
statmy <- function(x, plot.it = TRUE) {
  # @param plot.it 逻辑值，指示是否绘制处理结果的图形，默认为 TRUE
  # 输入x为向量，plot.it决定是否绘图
  if (!is.vector(x)) stop('argument x is not a vector, please check it.')

  # 检查是否为数值型
  if (!is.numeric(x)) stop('argument x is not a numeric, please check it.')

  # 计算统计量
  mean <- mean(x)
  median <- median(x)
  maximum <- max(x)
  minimum <- min(x)
  sd <- sd(x) # 计算标准差
  # 偏度（skewness）、峰度（kurtosis）以及 Jarque-Bera 正态性检验结果
  skew <- moments::skewness(x)  # 需要'moments'包
  kurt <- moments::kurtosis(x)  # 计算峰度
  jbtst <- moments::jarque.test(x)  # JB检验

  # 结果整理
  stats <- c(mean = mean, median = median, maximum = maximum,
             minimum = minimum, sd = sd, skew = skew, kurt = kurt)
  JBtest <- c(JB = jbtst$statistic, p.value = jbtst$p.value)

  # 绘图(optional)
  if (plot.it){ # 绘制QQ图和密度图:当 plot.it = TRUE 时，绘制：
  # Q-Q 图（用于正态性检查）；
  # 密度图 + 正态分布拟合曲线（红色虚线）。
    # 设置图形参数，以便在一个窗口中绘制两个图形，并调整边距
    par(mfrow = c(1,2), mar = c(4, 4, 2, 1))
    # 绘制x的QQ图，以检查x是否符合正态分布
    qqnorm(x)
    # 在QQ图上添加一条参考线，以帮助评估数据的正态性
    qqline(x)
    z <- density(x)
    # 调用plot() 函数
    plot(z, main = "Density Comparison",
         xlab = "Variable Distribution",
         ylab = "Density",
         xlim = c(min(x), max(x))) # x轴范围
    x2 <- c(min(x):max(x)) # 构造一个从最小到最大值的整数序列x2
    lines(x2, dnorm(x2, mean = mean(x), sd = sd(x)), col = "red", lty = 2)
    # 使用lines()添加一条红色虚线表示正态分布密度曲线
  }
  # 返回结果
  results <- list(obs = length(x), # 样本数量
                  stats = round(stats, digits = 3), # 统计指标
                  JBtest = round(JBtest, digits = 3)) # JB 检验结果,保留3位小数
  return(results)
}
# %%
?par
?qqnorm
?qqline