## 初始化准备
# 1) 设置工作路径、清除工作空间中的数据对象
setwd('G:/R learning/3 Finance with R/data and R files/CH 4')  # 设置工作目录
rm(list = ls())  # 清除当前工作空间中的所有对象、





## 数据手工输入
# 1) 输出向量
(x<-c(11,12,13,14,15))  # 创建并打印数值向量
(x = 16:20)  # 创建并打印16到20的序列

# 2) 输入数组
x<-1:12  # 创建1到12的序列
a<-array(data=x,dim=c(3,4))  # 将序列转换为3行4列的数组         
print(a)  # 打印数组

# 3) 输入数据框 
time<-c('2014-2-24','2014-2-25','2014-2-26','2014-2-27','2014-2-28')  # 创建日期向量
AAPL.Volume<-c(10318200,8284000,9864900,10781500,13284600)  # 创建交易量向量
AAPL.Adjusted<-c(527.55,522.06,517.35,527.67,526.24)  # 创建调整价格向量
AAPL<-data.frame(time,AAPL.Volume,AAPL.Adjusted)  # 将三个向量组合成数据框    
print(AAPL)  # 打印数据框

# 4) 输入列表
time<-c('2014-2-24','2014-2-25','2014-2-26','2014-2-27','2014-2-28')  # 创建日期向量
AAPL.Volume<-c(10318200,8284000,9864900,10781500,13284600)  # 创建交易量向量
AAPL.Adjusted<-c(527.55,522.06,517.35)  # 创建调整价格向量(注意长度不匹配)
mylist<-list(time=time,volume=AAPL.Volume,adjusted=AAPL.Adjusted)  # 创建列表
print(mylist)  # 打印列表




## 读取 Excel 文件

# 1) 采用剪贴板方法 
data <- read.delim('clipboard')  # 从剪贴板读取数据  
print(data)

# 2) 先另存为txt或csv文件格式 
(data <- read.table('BalanceSheet.txt'))  # 读取文本文件     
(data <- read.csv('BalanceSheet.csv'))  # 读取CSV文件       

# 3) 采用openxlsx包
(openxlsx::read.xlsx('BalanceSheet.xlsx', 'accounting'))  # 读取Excel指定工作表

# 4) 采用readxl包
(readxl::read_excel('BalanceSheet.xlsx', 'accounting'))  # 读取Excel指定工作表

# 5) 采用RODBC包
BalanceSheet <- RODBC::odbcConnectExcel2007('BalanceSheet.xlsx')  # 连接Excel文件
(RODBC::sqlFetch(BalanceSheet, 'accounting'))  # 获取指定工作表数据

# 6) 采用xlsx包(略)
library(xlsx)
(data <- read.xlsx('BalanceSheet.xlsx', 1))  # 读取第一个工作表            
(data <- read.xlsx('BalanceSheet.xlsx', 'accounting'))  # 读取指定工作表     





## 读取外部数据源

library(foreign)
(datspss <- read.spss('Data.sav'))  # 读取SPSS格式数据
names(datspss)  # 查看变量名
class(datspss)  # 查看数据类型

# 从网络读取Stata格式数据
hseinv <- read.dta("http://fmwww.bc.edu/ec-p/data/wooldridge/hseinv.dta")
head(hseinv)  # 查看前几行数据
res1 <- lm(log(invpc) ~ log(price), data=hseinv)  # 建立线性模型
summary(res1)  # 查看模型摘要



# 数据的预处理
## 加载相关的包

library(timeSeries)  # 时间序列处理包                              
library(tseries)  # 时间序列分析包                                  
library(quantmod)  # 量化金融分析包         





## 时序数据的处理

## 读取Excel文件数据(方法3、方法4)
### 将"数据框"含因子日期的数据，转化为"多元xts时序变量"

# 方法3:使用openxlsx包
library(openxlsx)
assets <- read.xlsx("assets.xlsx", "Sheet1")  # 读取Excel文件
class(assets)  # 查看数据类型

# 方法4:使用readxl包
library(readxl)
assets <- read_excel(path="assets.xlsx", sheet="Sheet1")  # 读取Excel文件
class(assets)  # 查看数据类型

head(assets)  # 查看前几行数据
dim(assets)  # 查看数据维度
class(assets$date)  # 查看日期列的类型      
timeindex <- as.Date(assets$date)  # 转换为Date类型
class(as.Date(assets$date))  # 再次确认类型
assets <- xts(assets[, 2:13], order.by = timeindex)  # 转换为xts时间序列对象
head(assets)  # 查看转换后的数据       
class(assets)  # 查看最终数据类型

## 2) 子集选择
assets <- assets[,c('AAPL.Close', 'GOOG.Close')]  # 选择两列数据     
dim(assets)  # 查看维度
head(assets)  # 查看前几行

assets['2016-10']  # 选择2016年10月的数据                                    
assets[start(assets),]  # 选择起始日期的数据                              
assets[end(assets),]  # 选择结束日期的数据                                

subset(assets, (assets[,1]>100) & (assets[,2]<750))  # 条件子集选择  
assets[(assets[,1]>100) & (assets[,2]<750), ]  # 另一种条件子集选择方式        

## 3) 随机抽样、按时序排序
assets.ts <- as.timeSeries(assets)  # 转换为timeSeries对象                
class(assets.ts)  # 查看类型
dim(assets.ts)  # 查看维度
assets.samp <- sample(assets.ts, size=100)  # 随机抽取100个样本          
dim(assets.samp)  # 查看样本维度
print(assets.samp)  # 打印样本
sort(assets.samp)  # 按时间排序             

## 4) 补齐数据
assets.ali <- align(assets.samp, by='1d', method='before', include.weekends=FALSE)
dim(assets.ali)  # 查看维度
print(assets.ali)  # 打印补齐后的数据

## 5) 数据频度转换
assets.m <- to.monthly(assets)  # 转换为月度数据
print(assets.m)  # 打印月度数据

## 修正补充：单独转换每列数据
asset1.m <- to.monthly(assets$AAPL)  # 转换AAPL列为月度数据
print(asset1.m)  # 打印结果
asset2.m <- to.monthly(assets$GOOG)  # 转换GOOG列为月度数据
print(asset2.m)  # 打印结果