############   第二章  R语言编程基础2   ###########
?setwd
setwd("/Users/wtsama/Documents/code/code2/R/project/")

rm(list = ls())    # 清除内存空间里的所有对象，为新写脚本文件作准备



#########################################################
#####  Section 2.1： 数据管理   ######


### 1.变量重命名(***)：names()，colnames()
    ## 1) fix()函数：交互式编辑器
(score <- data.frame(student = c("A", "B", "C", "D", "E"),
                     gender = c("M", "M",  "F", "F",  "M"),
                     math = c(90, 70, 80, 60, 70),
                     Eng = c(88, 78, 69, 98, 71),
                     p1 = c(66, 59, NA, 88, 73)))

fix(score) # 依赖于XQuartz
score.list <- as.list(score)
fix(score.list)




    ## 2) rename()函数：可修改数据框或列表的变量名，但不能修改矩阵的变量名
library(reshape)       # 加载reshape包
rename(score, c(p1 = "Chinese"))
rename(score.list, c(p1 = "Chinese"))




    ## 3) names()函数(***)：可修改数据框或列表的变量名，但不能修改矩阵的变量名
names(score)
names(score)[5] <- "Chinese"
score



    ## 4) colnames()函数(**)：可修改数据框、列表、及矩阵的变量名
colnames(score)[5] <- "Chinese"
rownames(score) <- letters[1:5]
score









### 2. 缺失、重复与异常值的清洗
    ## 1) 缺失值的发现与清洗
is.na(score)
anyNA(score)
na.omit(score)

complete.cases(score)
which(complete.cases(score)==F)
score[complete.cases(score), ]


saledata <- read.csv(file = "catering_sale.csv", header = TRUE, fileEncoding="GBK")
head(saledata)
names(saledata) <- c("date", "sale")
head(saledata)
sum(complete.cases(saledata)) # 返回一个逻辑向量，表示每一行是否不含任何缺失值（TRUE 表示该行完整）。
sum(!complete.cases(saledata))

mean(!complete.cases(saledata))
saledata[!complete.cases(saledata), ] # 筛选出 saledata 数据框中存在缺失值（NA）的行




    ## 2) boxplot()：异常值检测
# 绘制箱线图，使用较小的boxwex值以使箱线图更窄
(sp <- boxplot(saledata$sale, boxwex = 0.33))

# 绘制默认宽度的箱线图
(sp <- boxplot(saledata$sale))

# 输出箱线图中的异常值
sp$out

# 查找并输出saledata中sale值为6607.4的行索引
which(saledata$sale == 6607.4)

# 将saledata中sale的第9个值设置为NA
saledata$sale[9] = NA





    ## 3) 重复值分析：duplicated(), unique()
(x = rbind(5:10, runif(6), runif(6), 5:10, 11:16))
(y = sample(1:20,20, rep=T))
duplicated(x)
duplicated(y)

x[!duplicated(x), ]
unique(x)

y[!duplicated(y)]
unique(y)










### 3. 数据转换、排序、抽样与概率分布
    ## 1) 数据转换
    ## a) 简单函数变换：对数log()，指数exp()，差分diff()，累加cumsum()等


    ## b) 规范化**
data <- read.csv('normalization.csv', header = FALSE)
head(data)

    ### b1) 最小-最大规范化：极差标准化*，映射到[0, 1]区间
b1 <- (data[, 1] - min(data[, 1])) / (max(data[, 1]) - min(data[, 1]))
b2 <- (data[, 2] - min(data[, 2])) / (max(data[, 2]) - min(data[, 2]))
b3 <- (data[, 3] - min(data[, 3])) / (max(data[, 3]) - min(data[, 3]))
b4 <- (data[, 4] - min(data[, 4])) / (max(data[, 4]) - min(data[, 4]))
(data_scatter <- cbind(b1, b2, b3, b4))


    ### b2) 均值-标准差规范化：标准差标准化**
data_zscore <- scale(data)
?scale






    ## 2) 数据排序(***)：order()
    ## sort()函数
sort(score$math)
sort(score$math, decreasing = TRUE)
# 将score数据框中的Chinese列进行排序
# 参数na.last = TRUE表示将NA值放在排序后的末尾
sort(score$Chinese, na.last = TRUE)
?sort


    ## rank()函数
x <- c(3, 4, 2, 5, 5, 3, 8, 11)
rank(x)


    ### order()函数：既可对向量排序，又可对“数据框排序”(***)
order(score$math)
score$math[order(score$math)]
score[order(score$math), ]
score[order(-score$math), ]
score[order(score$math, score$Eng), ]




    ## 3) 随机抽样：sample()
    ## a) sample()函数(***)：简单随机抽样，也可“随机分组”
sample(1:100, 20)
# replace：为一个逻辑值，默认值是 FALSE。当 replace = FALSE 时，意味着不允许重复
# 抽样，也就是每个元素在抽样过程中最多只能被选中一次；当 replace = TRUE 时，表明
# 允许重复抽样，即同一个元素可能会被多次选中。
sample(1:100, 20, replace=T)
set.seed(623)    ;   sample(1:1000,15)
sample(1:1000,15)
sample(1:100, 20, prob=1:100)


LETTERS
sample(LETTERS, 5, replace=TRUE)
sample(LETTERS, 5, replace=FALSE)


    ### 随机分组 (略)：将26个元素(此处为字母)、分为2组，第1组和第2组比例为7:3
(n <- sample(2, 26, replace = T, prob = c(0.7, 0.3)))
length(n)  ;   class(n)  ;  mode(n)  ;   typeof(n)
(sample1 <- LETTERS[n == 1])
(sample2 <- LETTERS[n == 2])

    ## 更一般的随机分组例子
x <- -499:500         ;   length(x)
(n <- sample(4, length(x), replace = T, prob = c(0.1, 0.2, 0.3, 0.4)))
(x1 <- x[n == 1])     ;   length(x1)     # 第1组，子样本1
(x2 <- x[n == 2])     ;   length(x2)     # 第2组，子样本2
(x3 <- x[n == 3])     ;   length(x3)     # 第3组，子样本3
(x4 <- x[n == 4])     ;   length(x4)     # 第4组，子样本4
x



    ## 4) 概率统计：数据的分布、统计、算术、累积运算(***，略：第1讲的向量中已讲)
    ###  “d/p/q/r + 分布名称”，密/概/分/数
    ###  离散型：binom(二项)，nbinom(负二项)，geom(几何)，hyper(超几何)，pois(泊松)
    ###  连续型：unif(均匀)，norm(正态)，chisq(卡方)，t(t)，f(F)，gamma(伽玛)，exp(指数)，beta(β)，triangle(三角)
    ###  更多分布函数： https://cran.r-project.org/web/views/Distributions.html






### 4. 字符串处理(***)：查询、替换、连接，grep()、sub()、paste()
    ## 1) 正则表达式(*)
# 正则表达式，即用于“描述与匹配、一个文本集合的表达式”
# 元字符，不用来描述它自身、而被“转义”了，如表示重复操作的元字符 ( {}、*、+、? )
# 运算顺序：圆括号 > 表示重复次数的操作 > 连接运算  > 可选项运算(|)



    ## 2) 字符串查询(***)：grep()、substr()、gregexpr()
txt <- c("Whatever", "is", "worth", "doing", "is", "worth", "doing", "well")
nchar(txt)
grep("e.*r|wo", txt, fixed = FALSE)
grepl("e.*r|wo", txt)
(sentence <- paste("Whatever", "is", "worth", "doing", "is", "worth", "doing", "well", sep=" "))
substr(sentence, 10, 23)
?substr




    ## 3) 字符串替换(***)：sub()，gsub()
sub("[tr]", "k", txt) # 被替换的（方框以内的），替换成的，sub只替换成对应的字符
gsub("[tr]", "k", txt) # gsub会用相同




    ## 4) 字符串拆分：strsplit()
data <- c("2016年1月1日", "2016年2月1日")
strsplit(data, "年")
strsplit(data, "年")[[1]][2]



    ## 5) 字符串连接(***)：paste()、cat()
paste("xy", 1:5, sep = "")
paste("xy", 1:5, sep = "", collapse = ";")
cat("xy", 1:5, sep = "")


    ### 利用列表，连接“两个字符向量的对应元素/字段”
x <- list(a = "1st", b = "2nd", c = "3rd")
y <- list(d = 1, e = 2)
paste(x, y, sep = "-")
paste(x, y, sep = "-", collapse = "; ")
paste(x, collapse = " , ")










#########################################################
#####  Section 2.2： 控制语句与函数编写   ######


### 1. 控制语句 (分支 + 循环)：“条件if/switch + 循环for/while/repeat”
    ## 1) 分支/条件语句：if, switch
    ### a) if_else 条件结构***、if条件句
    ### 若 a<=0, result=0; 0<a<1, result=1; a>=1, result=2
a <- 0.38
if (a <= 0)  {
    result <- 0
}  else if (a < 1)    result <- 1   else
    result <- 2

result


x <- -3:3
ifelse(x>0, sqrt(x), x^2) # 会有warning
sqrt(ifelse(x>0, x, x^4)) # 没有



    ### 单条if语句 (条件为假时，直接跳过条件句、执行其他语句)：if(cond) {expr} 其它语句
fun.algorithm <- function(x, y, method = "add") # method = "add"是默认参数
{
    if(method == "add")          res <- x + y
    if(method == "substract")    res <- x - y
    if(method == "乘")           res <- x * y
    if(method == "幂运算")       res <- x^y
    return(res)
} # 自定义函数

    ## 算法函数的调用，结果检验
fun.algorithm(x = 10, y = 4)
fun.algorithm(x = 10, y = 4, method = "add")
fun.algorithm(x = 10, y = 4, method = "substract")
fun.algorithm(x = 10, y = 4, method = "幂运算")







    ## 2) 循环语句：for, while, repeat
    ### a) for循环(***)
n <- c(2, 100, 9, 5, 36)
for (i in n)
{  x <- sqrt(i)
cat("sqrt(", i, ") ＝", x, "\n")
}




    ### b) while循环(**)
    ### 生成50个数的费波那契数列
(x <- c(1, 2))
i <- 3
while (i <= 50) {
    x[i] <- x[i - 1] + x[i - 2]
    i <- i + 1 }
x

    ## 采用for循环，同样实现以上算法
(x <- c(1, 2))
for(i in 3:50) {
    x[i] <- x[i - 1] + x[i - 2]
}
x




    ### c) repeat-break循环：repeat {if(cond) break expr}
    ### 根据用户的访问/点击数pv，将用户分别标记为“初级用户”、“中级用户”或“高级用户”
pv <- c(1, 1, 2, 3, 1, 1, 15, 7, 18)
i <- 1
result <- ""
repeat{
    if (i > length(pv)) {
        break # nolint
    }
    if (pv[i] <= 5) {
        result[i] <- "初级用户" # nolint: indentation_linter.
    } else if (pv[i] <= 15) {
        result[i] <- "中级用户"
    } else {
        result[i] <- "高级用户"
    }
    i <- i + 1
}
result



d <- c(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
d_m <- sum(d) / length(d)
d_m
?repeat



### 2. 函数编写(**)
    ### a) 自编函数计算标准差
sd2 <- function(x) {
    if (!is.numeric(x)) {
        stop("the input data must be numeric!\n")
    }
    if (length(x) == 1){
        stop("can not compute sd for one number,
         a numeric vector required.\n")
    }
    dv <- c()
    dv2 <- c()
    for (i in 1:length(x)) {
        dv[i] <- x[i] - mean(x)
        dv2[i] <- dv[i] ^ 2
    }
    sum2 <- sum(dv2)
    sd <- sqrt(sum2 / (length(x) - 1))
    return(sd)
}


    ## 程序的检验
sd2(c(2, 6, 4, 9, 12, 3, 2))
sd2(3)
sd2(c("1", "2"))


    ## 与R基础函数sd()运行结果的比较
sd(c(2, 6, 4, 9, 12, 3, 2))
sd(3)
sd(c("1", "2"))
sd(1:2)






# %%
    ### b) 自定义一个“描述性统计 + 绘图”的向量函数，读取数据后、再调用函数
    ## b1) 先读取数据
    ### 读入xls文件：方法1
library(RODBC) # RODBC 已过时
SSEC_Data <- odbcConnectExcel2007("stock index.xlsx")
SSEC <-sqlFetch(SSEC_Data, 'SSEC')
SSEC_shjc <- sqlFetch(SSEC_Data, 'SSEC-600009')
head(SSEC_shjc)
SSEC_scgf <- sqlFetch(SSEC_Data, 'SSEC-600008')
SSEC_zggm <- sqlFetch(SSEC_Data, 'SSEC-600007')
close(SSEC_Data)
detach(package:RODBC)



# %%

    ### 读入xlsx文件：方法2
setwd('/Users/wtsama/Documents/code/code2/R/project/')
library(openxlsx)
SSEC <- read.xlsx("stock index.xlsx", 'SSEC')
SSEC_shjc <- read.xlsx("stock index.xlsx", 'SSEC-600009')
head(SSEC_shjc)
SSEC_scgf <- read.xlsx("stock index.xlsx", 'SSEC-600008')
SSEC_zggm <- read.xlsx("stock index.xlsx", 'SSEC-600007')




    ## b2) 调用自定义的函数、计算
    ## 方法1：直接在R-studio中运行Rfunction-Statistic.R文件中的“自编函数statmy()”，运行后、再调用
(SSEC_shjc_stat <- statmy(x=SSEC_shjc[,2], plot.it=TRUE))
(SSEC_scgf_stat <- statmy(x=SSEC_scgf[,2], plot.it=TRUE))
(SSEC_zggm_stat <- C_zggm[,2], plot.it=TRUE))

stats <- rbind(SSEC_shjc_stat$stats, SSEC_scgf_stat$stats, SSEC_zggm_stat$stats)
rownames(stats) <- c('shjc', 'scgf', 'zggm')
print(stats)
tests <- rbind(SSEC_shjc_stat$JBtest, SSEC_scgf_stat$JBtest, SSEC_zggm_stat$JBtest)
rownames(tests) <- c('shjc', 'scgf', 'zggm')
print(tests)



    ## 方法2：利用source()命令，调用含“自编函数statmy()”的R文件Rfunction-Statistic.R , 即可
rm("statmy")
source("/Users/wtsama/Documents/code/code2/R/Rfunction-Statistic.R")
# %%










#########################################################
#####  Section 2.3： 程序调试   ######


### 1. 案例1：“自编函数statmy()”的调试
    ## 1) 利用debug()函数，打开browser浏览器、展开调试
source('Rfunction-Statistic.R')
debug(statmy)
data.sim.1 <- rnorm(1000)
data.sim.2 <- matrix(rnorm(2000), nrow=2)
statmy(x=data.sim.1, plot.it=TRUE)
statmy(x=data.sim.2, plot.it=TRUE)



    ## 2) 利用browser()函数，打开browser浏览器、展开调试
rm(list=ls())
source('sub-01.R')
set.seed(12345)
data.sim.1 <- rnorm(1000)
data.sim.2 <- matrix(rnorm(2000), nrow=2)
statmy(x=data.sim.1, plot.it=TRUE)
statmy(x=data.sim.2, plot.it=TRUE)











#########################################################
#####  Section 2.4： 绘图   ######


### 2.4.4  图形组合与保存


### 1. 图形组合
    ## 1) par()：设置大多数绘图的“全局参数”，mfrow/mfcol (“均衡的”分隔图面); mar/mai, oma, mgp
mfrow1 <- par(mfrow = c(2, 3))
for (i in 1:6) {
    plot(c(1:i), main = paste("I'm image:", i))
}




    ## 2) layout()：“不均衡的”分隔图面
(mat <- matrix(c(1, 2, 2, 3, 3, 3, 4, 4, 4, 5, 5, 6), nrow = 2, byrow = TRUE))
layout(mat)
for (i in 1:6) {
    plot(c(1:i), main = paste("I'm image:", i))
}






        ### 2.4.5  绘图案例

### 1. plot “泛型”类函数的演示*
set.seed(12345)
x <- sample(c(1:100),100)
y <- sample(1:100,100)
xt <- ts(x)
xy <- cbind(x, y)
class(xy)
xy1 <- rbind(x,y)
f <- as.factor(c(rep('A',20),rep('B',30),rep('C',50)))
f
par(mfcol=c(2,4),mar=c(5,4,3,2))
plot(x)
plot(xt)
plot(xy)
plot(x,y)
plot(y~x)
plot(f)
plot(table(f)/length(f))
plot(f,y)




### 2. pairs and coplot function demo (略)




###  3 绘图大案例：上证指数及上市个股的对数收益率分布特征***
    ## 1) 读取Excel数据
    ### 读入xls文件：方法1
library(RODBC)
SSEC_Data <- odbcConnectExcel2007('stock index.xls')
SSEC <-sqlFetch(SSEC_Data, 'SSEC')
class(SSEC)
SSEC_scgf <- sqlFetch(SSEC_Data, 'SSEC-600008')
SSEC_zggm <- sqlFetch(SSEC_Data, 'SSEC-600007')
close(SSEC_Data)
detach(package:RODBC)



    ### 读入xlsx文件：方法2
library(openxlsx)
SSEC <- read.xlsx("stock index.xlsx", 'SSEC')
SSEC_shjc <- read.xlsx("stock index.xlsx", 'SSEC-600009')
head(SSEC_shjc)
SSEC_scgf <- read.xlsx("stock index.xlsx", 'SSEC-600008')
SSEC_zggm <- read.xlsx("stock index.xlsx", 'SSEC-600007')


    ## 2) 计算对数收益序列
head(SSEC)
Close.ptd.SSEC <- SSEC$SSEC_Close
Close.rtd.SSEC <- diff(log(Close.ptd.SSEC))*100



    ## 3) 从各自个股的数据框中、提取相应的收盘价
head(SSEC_shjc)
Close.ptd.shjc <- SSEC_shjc$SSEC_600009_Close
Close.ptd.scgf <- SSEC_scgf$SSEC_600008_Close
Close.ptd.zggm <- SSEC_zggm$SSEC_600007_Close



    ## 4) 绘制上证指数收益时间序列图、散点图、自相关图与偏自相关图
## win.graph(width=7,height=6.5)
par(mfrow=c(2,2),mar=c(5,4,3,2))

    ## 若日期以数值形式显示并存储，则先将“数值日期”、转换为“日期变量”
class(SSEC$SSEC_Date)
SSEC$SSEC_Date <- as.Date(SSEC$SSEC_Date, origin="1899-12-30")
class(SSEC$SSEC_Date)
head(SSEC)

which(SSEC$SSEC_Date=="2010-12-31")
Close.ptd.SSEC.ts<-ts(Close.ptd.SSEC,start=c(2010,1,4),freq=242)
plot(Close.ptd.SSEC.ts, type="l",main="(a) 上证指数日收盘价序列图",
     xlab="Date",ylab="Price",cex.main=0.95,las=1)

plot(Close.ptd.shjc[1:20], type="p",pch=17,main="(b) 上证指数样本股散点图",
     xlab="Time",ylab="Price",cex.main=0.95,ylim=c(4,14),las=1)
points(Close.ptd.scgf[1:20],pch=15)
points(Close.ptd.zggm[1:20],pch=14)
legend("bottomright", legend=c("SHJC_600009","SCGF_600008","ZGGM_600007"),
       pch=c(17,15,14),cex=0.6,lty=c(-1,-1,-1))


acf(Close.rtd.SSEC,main='',xlab='Lag',ylab='ACF',las=1)
title(main='(c) 上证指数收益率自相关检验',cex.main=0.95)

pacf(Close.rtd.SSEC,main='',xlab='Lag',ylab='PACF',las=1)
title(main='(d) 上证指数收益率偏自相关检验',cex.main=0.95)



    ## 5)  Q-Q图、 经验累积分布ecdf图(略讲)、 密度图、直方图
## win.graph(width=7,height=6.5)
par(mfrow=c(2,2),mar=c(5,4,3,2))

qqnorm(Close.rtd.SSEC,main="(a) 上证指数收益率Q-Q图",cex.main=0.95,
       xlab='理论分位数',ylab='样本分位数')
qqline(Close.rtd.SSEC)


(ECD.SSEC <- ecdf(Close.rtd.SSEC[1:10]))
class(ECD.SSEC)
plot(ECD.SSEC,lwd = 2,main="(b) 上证指数收益率累积分布函数图",cex.main=0.95,las=1)
(xx <- unique(sort(c(seq(-3, 2, length=24), knots(ECD.SSEC)))))
lines(xx, ECD.SSEC(xx))
abline(v = knots(ECD.SSEC), lty=2, col='gray70')
x1 <- c((-4):3)
lines(x1,pnorm(x1,mean(Close.rtd.SSEC[1:10]),sd(Close.rtd.SSEC[1:10])))


D <-density(Close.rtd.SSEC)
plot(D, main="(c) 上证指数收益的核密度图 ",xlab="收益", ylab='密度',
     xlim = c(-7,7), ylim=c(0,0.5),cex.main=0.95)
polygon(D, col="gray", border="black")
curve(dnorm,lty = 2, add = TRUE)

x2 <- c(-7:7)
lines(x2,dnorm(x2,mean=0,sd=1),lty=2,col=2)
abline(v=0,lty = 3)
legend("topright", legend=c("核密度","正态密度"),lty=c(1,2),col=c(1,2),cex=0.5)



hist(Close.rtd.SSEC[1:100],xaxt='n',main='(d) 上证指数收益率直方图',
     xlab='收益/100',ylab='密度', freq=F,cex.main=0.95,las=1)
summary(Close.rtd.SSEC[1:100])
x2 <- seq(-6, 4, by=0.01)
lines(x2,dnorm(x2,mean(Close.rtd.SSEC[1:100]),sd(Close.rtd.SSEC[1:100])))
axis(1,at=axTicks(1),labels = as.integer(axTicks(1))/100 )


x <- matrix(1:6, nrow = 2)
x
(y <- matrix(1:6, 2))
result <- apply(x, 2, sum)
print(result)

(x <- list(a = 1:2, b = 3:5))
result <- sapply(x, function(y) y[3])
print(result)

x <- matrix(1:9, nrow = 3)
results <- apply(x, 1, function(row) c(min = min(row), max = max(row)))
class(results)
typeof(results)
mode(results)



