############   Section 5.2: 基础金融计算  ###########


### 加载必要的包
library(zoo)                    # 处理时间序列数据
library(timeSeries)             # 金融时间序列分析

### 1. 单一资产计算
    ## 1) 从txt文件读取数据
setwd('/Users/wtsama/Documents/code/code2/R/data/attached for 5')
da <- read.table("5-1.txt", head=T, colClasses="character")    # 读取带表头的文本数据
head(da) ; tail(da)  # 查看数据首尾

# 转换数据类型
clsprc <- as.numeric(da[,3])               # 将价格列转为数值型
dates <- as.Date(da[,2])                   # 将日期列转为日期格式
(cls <- zoo(clsprc, dates))                # 创建zoo时间序列对象
head(cls)

# 计算滞后价格
(lclsprc <- lag(cls, k=-1))                # 计算滞后一期的价格
head(lclsprc)

# 调整数据长度
clsprc <- as.numeric(da[2:237,3])         # 原始价格（去掉首行）
lclsprc <- as.numeric(lclsprc)             # 滞后价格
length(clsprc); length(lclsprc)            # 检查数据长度


    ## 2) 计算日收益率（三种方法）
re <- 100 * (log(clsprc)-log(lclsprc))    # 手动计算对数收益率                    
re.2 <- 100 * diff(log(cls))              # 使用diff计算
re.3 <- returns(cls, method='continuous', percentage=TRUE) # 使用returns函数计算

# 验证三种方法结果是否相同
identical(re, as.numeric(re.2))
identical(re, as.numeric(na.omit(re.3)))                    


    ## 3) 计算算术平均收益率
(am <- mean(re))                          # 手动计算结果                        
(am.1 <- mean(re.2))                      # diff计算结果
(am.2 <- mean(re.3, na.rm=TRUE))          # returns函数计算结果


    ## (4) 计算几何平均收益率
(gm <- 100* (cumprod(re/100+1)[length(cumprod(re/100+1))]^(1/length(re))-1))       
# (cumprod(re/100+1)是一个列表

    ### 比较cumprod()和prod()函数
(gm <- 100*(prod(re/100+1)^(1/length(re))-1))  # 使用prod计算几何平均
(cumprod(1:10))  # 累积乘积示例
(prod(1:10))     # 总乘积示例


### 2. 多资产计算
    ## (1) 读取两个资产数据并合并
da1 <- read.table("CAQC.txt",head=T,colClasses="character")  # 读取资产1数据
da2 <- read.table("ZXTX.txt",head=T,colClasses="character")  # 读取资产2数据

# 数据处理
wcls1 <- as.numeric(da1[,3])  # 资产1价格
wcls2 <- as.numeric(da2[,3])  # 资产2价格
dates1 <- as.yearmon(da1[,2]) # 资产1日期             
dates2 <- as.yearmon(da2[,2]) # 资产2日期

# 创建时间序列对象
cls1 <- zoo(wcls1, dates1)  
cls2 <- zoo(wcls2, dates2)

# 合并数据
dat.merge <- merge(cls1, cls2)  # 按日期合并两个资产               

    ## 使用xts包处理数据
library(xts)  
cls11 <- xts(wcls1,order.by=dates1)  # 创建xts对象         
cls22 <- xts(wcls2,order.by=dates2)
dat.merge.xts <- merge(cls11, cls22)

    ## 2) 计算合并后的收益率
r.merge <- returns(dat.merge, method='continuous', percentage=TRUE)
(r.merge2 <- returns(dat.merge, method='continuous'))  # 不转换为百分比


### 3. 投资组合计算
    ## 1) 读取股票数据并处理缺失值
da <- read.table("5-3.txt", head=T)
sum(is.na(da))                         # 检查缺失值
p.app <- na.approx(da)                 # 使用线性插值填充缺失值

# 计算股票收益率
r.stocks <- diff(log(p.app))*100       # 对数差分计算收益率               

    ## 2) 生成随机权重
set.seed(12345)  # 设置随机种子
(w <- runif(ncol(da), 0, 1))          # 生成均匀分布随机数
(w <- w/sum(w))                   # 归一化为权重向量
sum(w)  # 验证权重和为1

    ## 3) 计算组合收益率
rp <- r.stocks %*% w  # 矩阵乘法计算组合收益率                


##### section 5.3 收益率计算进阶


### 1. 债券收益率计算
    ## 1) 定义计算函数           
f <- function(r, p, Cs){
  n <- length(Cs)                 
  tt <- 1:n                       
  loss <- p - sum(Cs/((1+r)^tt))  # 计算价格与现值之差
  loss
}

    ## 2) 计算具体案例
Cs <- c(20000, 20000, 25000, 40000)  # 现金流     
p <- 77040  # 债券价格
r <- uniroot(f, c(0,1), p=p, Cs=Cs)  # 求解收益率
r$root  # 输出内部收益率

    ### 验证计算结果
n <- length(Cs)    
tt <- 1:n 
(p <- sum(Cs/((1+r$root)^tt)))  # 根据收益率计算现值


### 2. 附息债券计算
    ## 1) 定义计算函数
f_exp <- function(r, p, Cs, Cp){
  n <- length(Cs)
  tt <- 1:n
  loss <- p - sum(Cs/((1+r)^tt)) - Cp/(1+r)^n  # 包含本金现值
  loss
}

    ## 2) 案例1计算
Cs <- rep(2000000, times=40)  # 40期现金流 
Cp <- 25000000                # 到期本金              
p <- 23640000  # 债券价格
uniroot(f_exp, c(0,1), p=p, Cs=Cs, Cp=Cp)  # 求解收益率          
    
    ## 3) 案例2计算与决策
Cs <- rep(950000, times=30)                   
Cp <- 15000000
p <- 22710000
r.half <- uniroot(f_exp, c(0,1), p=p, Cs=Cs, Cp=Cp)$root         
( r.annualized <- (1+r.half)^2-1 )  # 年化收益率          
r.expected <- 0.067  # 预期收益率

# 投资决策
if (r.annualized>=r.expected) {
  cat('执行投资，内部收益率为', r.annualized, '\n')
} else {
  cat('放弃投资，内部收益率为', r.annualized, '\n')
}


### 3. 有效年利率(EAR)计算
    ## 1) 定义计算函数
eff_rts <- function(pr,m){
  ear <- (1+pr)^m-1  # 有效年利率公式                
}

    ## 2) 计算示例
(da1 <- eff_rts(0.05,2))  # 半年复利5%的年化收益率       
(da2 <- eff_rts(0.025,4)) # 季度复利2.5%的年化收益率