############     第一章  R语言编程基础1     ###########
############     (尊重版权，勿网络传播)     ###########



#########################################################
#####  Section 1.1： 工作环境设置   ######

setwd('H:/R learning/3 Finance with R/data and R files/CH 1-2')
setwd('H:\\R learning\\3 Finance with R\\data and R files\\CH 1-2')
# 斜杠“ / ” ，或双反斜杠“ \\ ”
x <- c(1, 10, 100)
rm(list = ls())
# 清除内存空间里的所有对象，为新写脚本文件作准备









#########################################################
######     Section 1.2： 数据对象   ######



### 1. 对象
x <- 8
x
ls()        # List Objects：展示对象
rm(x)






### 2. 基本数据类型，5种：【数字逻复、时】*
# 1) numeric
x <- 12
length(x)
class(x)


# 2) character*
z <- "Display \"a\" string "
# 字符，须以“双引号、或单引号”引起来
# 双引号中、再引用“字符串中的双引号”，需用反斜杠“ \ ”隔开 (仅仅起分隔作用)
z    ;   print(z)
w <- 'Display "b"  string '
w    ;   cat(w)
cat(z,w)          # Concatenate and Print：连结、并打印
class(z)  ;  class(w)


# 3) logical
y <- TRUE
class(y)
length(y)


# 4) complex
m <- 2+3i
class(m)
length(m)




# 5) 时间型，日期/时间变量(***)：as.Date()、format()、as.POSIXlt()、strftime()
##  将“字符日期”，转换为“日期变量”(***)
## 字符日期，无法直接计算
(dates <- c("01/27/2016", "02/27/2016", "01/14/2016", "02/28/2016", "02/01/2016"))
# 创建“字符串日期”向量
is.numeric.Date(dates)      # 是否“数值日期变量”
is.character(dates)
(date <- as.Date(dates, format = "%m/%d/%Y"))
# 按照“月%m、日%d、年%Y的读入日期格式”进行“年月日”的日期变量转换
# as.Date()，只能转换“年月日星期”的字符日期，不能转换具体到“时分秒”的字符时刻
# 日期变量，可直接作运算、但仍不直接是数值/numeric
(dateplus <- date + 189)
class(date)
(dateform <- format(date, "%d/%m/%Y %a %b"))
# 日期变量，转换为“任意指定格式”的字符串
#  %a、%b，缩写的星期名、月份名
(dateform <- format(date, "%m-%d-%Y %A %B"))
# 与上类似，另一种指定字符格式
#  %A、%B，完整的星期名、月份名


##	 将“字符时间”，转换为“可计算的时间变量” (略)
x <- c("2016-02-08 10:07:52", "2016-08-07 19:33:02")
# 创建一个字符型日期时间变量
is.character(x)
# 判定是否为字符型变量
(as.POSIXlt(x, tz = "", format = "%Y-%m-%d %H:%M:%S"))
# 对字符时间值，按“读入字符时间的格式”(即要转换的x的格式)进行转换
# %M、%S，十进制的分钟、秒
# CST，为中国标准时区tz
(x <- strptime(x, "%Y-%m-%d %H:%M:%S", tz = ""))
# 按“年月日 时分秒”转换为时间变量，与as.POSIXlt()等效、但格式略有不同


##	 将“时间变量”转换为“字符日期” (略)
x <- strftime(x, format = "%m/%d/%Y")
# 将“日期/时间变量”，逆转为“字符串日期”(按format设定格式)，但不保留具体“小时/分/秒”
class(x)
format(x, "%Y-%m-%d %a %b")
# 输出格式，转换成format指定的字符串日期
# format()，还可将其他类型变量、转换成字符串








### 3. 向量(***)：创建(等差、重复)、索引、编辑；排序、描述性统计
## 1) 向量创建
## 非规则序列
x1 <- c(1,13,25,97)
# concatenate：连结函数，生成“普通/非规则数据的向量”
x2 <- c("a", "b", "c", "d")        # 创建字符型变量
x3 <- c(TRUE, FALSE, FALSE, TRUE)  # 创建逻辑型变量
class(x1)
# 数据对象类型为“数值型”、作为“值”存储，而非对象类型“vector”
mode(x1)
typeof(x1)           # 数据类型的细节展示(*)：typeof() > class() > mode()

## 等差序列(扩展：等比数列)
x <- c(1,2,3,4)
# 创建数值型向量,也可写成 x = 1:4 或 x = c(1:4)
(y <- 1:10)           # 生成“等差序列”向量：步长为1，直接用“ : ”实现
(z <- 3*2^(1:10))
# 将等差数列、放在指数上，即生成“等比数列”
1:10*2
1:10^2
# 向量生成运算符“ : ”的优先级，高于乘法运算*、但低于幂运算^
seq(1, -9)                      # 只给出首项和尾项数据，by自动匹配为1或-1
seq(1, -9, length.out = 5)      # 给出首项、尾项、及长度，自动计算等差
seq(1, -9, by = -2)             # 给出首项、尾项、及步长，自动计算长度
seq(1, by = 2, length.out = 10)
# by设置步长，length.out设置元素输出个数 (不引起混淆时，可简写为 “ length ”)

## 重复序列
rep(1:3, 2)
# Replicate：“重复生成”某一元素或对象
# 此处 times = 2 ，为重复次数
rep(1:3, each = 2)              # 序列中各个元素分别重复两次
rep(1:3, c(2, 1, 5))
# 按照指定规则、重复序列中的各个元素
rep(1:3, each = 2, length.out = 4)
# 序列中各个元素分别重复两次，规定生成序列的长度为4
rep(1:3, each = 2, times = 3)
# 序列中“各个元素”分别重复两次，“整个序列”重复3次
rep(as.factor(c("因子1", "因子2", "因子3")), 3)
# 将因子型变量序列重复3次

## 2)  向量索引
## “中括号 + 下标”索引(元素的值)
vector <- c(11, 12, 13, 14)      # 创建向量
vector[1]                    # 查看第一个元素
vector[c(1, 4)]              # 查看第一个与第四个元素
vector[-1]                   # 查看除了第一个元素之外的所有元素
vector[-c(1:3)]              # 查看除了前三个元素之外的所有元素
vector[c(TRUE, TRUE, FALSE, FALSE)]
# 通过“逻辑序列/向量”，查看前两个元素

## 按名称索引 (很少用)
names(vector)
names(vector) <- c("one", "two", "three", "four")
# 给向量中每个元素命名
vector[c("one", "two", "four")]
# 查看名称为“one”,“two”,“four”的元素

## which索引“满足逻辑条件的元素位置”(*)
which(vector == 13)               # 向量中等于13的元素所在的位置
which(vector == c(11, 14))        # 向量中等于11和14的元素所在的位置
which(vector != 12)               # 向量中不等于12的元素所在的位置
which(vector > 12 & vector < 14)
# 满足多重条件的元素所在的位置
which.max(vector)                 # 最大值所在的位置
which.min(vector)                 # 最小值所在的位置

## subset索引 (略)
subset(vector, vector > 11 & vector < 14)
# 检索向量中满足条件的元素
# 与普通筛选“ [ ] ”类似，区别只在于NA值的处理、subset()将直接剔除NA值的计算


## match方式索引   (*)
?match
match(vector, c(14, 11, 13))
# 判断向量x中的元素、是否等于table中的任一值，返回匹配值“在table中的位置” (不匹配的，返回NA)、即位置指针向量
vector[match(vector, c(14,11,13))]


## 值匹配符：x %in% table   (**)
c(11, 18) %in% vector
# 判断向量x的每一项元素/数据，是否包含在table中，返回“逻辑向量”结果
match(c(11, 18), vector)

### "%in%" <- function(x, table) match(x, table, nomatch = 0) > 0   (略)
?"%in%"


## 3) 向量编辑：元素的扩展及删除
x <- c(1, 2, 3, 4)
(x <- c(x, c(7, 8, 9)))
# 向量扩展：通过连接函数c()
(x <- append(x, 5:6, after=4))
# 向量扩展：通过append()，在指定位置添加元素
(x <- x[-1])
# 单个元素的删除
(x <- x[-c(3:5)])
# 多个元素的删除



## 4) 排序及倒序
x <- c(5, 6, 8, 7, 4, 1, 9)
x1 <- c("B", "A", "C")
x2 <- c(3, 2, NA, 1, 4, 5)
# 创建3个无序的向量
sort(x)
sort(x, decreasing = TRUE)
# 数值型数据排序(默认为升序)
order(x)
# 返回“升序排列sort(x)的元素、在原序列x中的位置” (**)
x[order(x)]
# 与sort(x)等价
sort(x1)                         # 字符型数据排序
sort(x2, na.last = TRUE)         # 将缺失值NA，放到最末尾
rev(x)                           # 倒序(并非按大小)


## 5) 向量的描述性统计、算术、累积运算
(x <- round(runif(20,1,1000), digits = 2))     # 四舍五入，保留小数点2位
###  “d/p/q/r + 分布名称”，密/概/分/数
###  离散型：binom(二项)，nbinom(负二项)，geom(几何)，hyper(超几何)，pois(泊松)
###  连续型：unif(均匀)，norm(正态)，chisq(卡方)，t(t)，f(F)，gamma(伽玛)，exp(指数)，beta(β)，triangle(三角)
###  更多分布函数： https://cran.r-project.org/web/views/Distributions.html
summary(x)    # 汇总
min(x)  ;  max(x)        # 极值区间，与range(x)类似
mean(x) ; median(x)      # 均值,中位数
var(x)        # 方差
sd(x) ; sqrt(var(x))     # 标准差,即方差的平方根
fivenum(x)    # 五数汇总 (计算规则，基于中位数)
quantile(x)   # 四分位数 (计算规则，完全基于分位数概念)
quantile(x,c(0, .33, .66, 1))
# 三分位数：指定“分位百分点”
mad(x)        # median average distance：“观测值对中位数偏离的绝对值”的算术平均

round(x)      # 等价于{ round(x,0) },四舍五入、取整
floor(x)      # 向下取整
ceiling(x)    # 向上取整

sum(x)        # 元素求和
cumsum(x)
# 累积和，与x等长 每个元素是该位置及之前所有元素的和。
cummax(x)  ; cummin(x)     # 累积最大值、累积最小值
prod(x) # prod(x) 是 R 语言中的一个函数，用于计算向量 x 中所有元素的乘积。
cumprod(x)    # 累积积
cor(x,sin(x/20))           # 线性相关系数



### 自编补充案例： 某工程项目进度总工期的随机模拟 (亦可用于作业成本法的总成本估算)
# 假设某项目关键路径上共有“8个作业单元”，时间参数分别服从正态分布(1、7、8)、三角分布(2~6)
u1 <- rnorm(1000000, 10, 2)
# 假设作业单元1，作业时间服从N(10, 2^2)的正态分布
library(triangle)    # 三角分布的相关函数，在triangle包中
u2 <- rtriangle(1000000, 5, 33, 11)
# 假设作业单元2，作业时间服从Tri(5, 33, 11)的三角形分布
# 生成10^6个工期三角分布的随机数
u3 <- rtriangle(1000000, 7, 28, 10)
u4 <- rtriangle(1000000, 4, 10, 8.5)
u5 <- rtriangle(1000000, 6, 29, 9)
u6 <- rtriangle(1000000, 9, 41, 13)
u7 <- rnorm(1000000, 15, 3)
u8 <- rnorm(1000000, 6, 2)
alltime <- u1 + u2 + u3 + u4 + u5 + u6 + u7 + u8
mean(alltime)
sd(alltime)
hist(alltime)
plot(density(alltime))
quantile(alltime, 0.9)
quantile(alltime, 0.95)
quantile(alltime, 0.99)
abline(v=mean(alltime), lty=3)
abline(v=quantile(alltime, 0.95), lty=3, col=3)
abline(v=quantile(alltime, 0.99), lty=1, col=2)
text((mean(alltime)-1), 0.003, "mean = 105.5")
text((quantile(alltime, 0.95)+9), 0.013, "95%分位数 = 126.7", col=3)
text((quantile(alltime, 0.99)+15), 0.028, "99%分位数 = 135.7", col=2)









### 4. 矩阵与数组(***)：创建、索引/筛选、编辑；运算
## 1) 矩阵创建
(x <- c(1:10))      # 创建一个向量，作为矩阵的数据
(a <- matrix(x, nrow = 5, ncol = 2, byrow = T))
# 创建一个矩阵，定义矩阵的行数为5、列数为2，按行读取数据
(b <- matrix(x))
# 未指定行列维数时，生成“矩阵形式的列向量”
dim(b) <- c(5, 2)
# 创建一个矩阵，定义矩阵的行数为5、列数为2，默认“按列读取/存储数据”
b
(c <- matrix(x, nrow = 5, ncol = 2,  byrow = F,
             dimnames = list(c("r1", "r2", "r3", "r4", "r5"), c("c1", "c2"))))
# 创建一个5行2列，按列读取数据的矩阵，dimnames定义矩阵行列的名称
length(c)    # 矩阵也是向量，其长度为矩阵元素的个数



## 2) 矩阵索引/筛选：“中括号 + 下标范围”；逻辑索引/筛选
x <- c(1:10)
(a <- matrix(x, nrow = 5, ncol = 2, byrow = F, # 按列
             dimnames = list(c("r1", "r2", "r3", "r4", "r5"), c("c1", "c2"))))
a[2, 1]           # 根据位置索引
a["r2", "c1"]     # 根据行和列的名称索引
a[1, ]            # 检索第一行
a[, 1]            # 检索第一列
a[c(3:5), ]       # 检索第3~5行
# 从矩阵或数据框中选取特定的行和列
# 此代码片段的目的是从一个矩阵或数据框中选取特定的行和列
# 它通过指定行和列的索引来实现这一目的
# 具体来说，它选取了除第2行和第4行之外的所有行，并且只选取第2列的数据
a[-c(2, 4), 2]
# 默认drop值为真，将返回一个“维数尽可能低的对象”(此处为向量)
a[-c(2, 4), 2, drop = F]
# 去掉第2行与第4行，提取第2列
# 但索引的是“单列子矩阵”，而不允许降维为向量
a[a[, 1]>3, ]
# 筛选条件为“比较表达式”时，依逻辑布尔值为真、筛选出“需要的矩阵的行或列”



## 3) 矩阵编辑：重置矩阵大小、行/列的合并与删除(*)
## 矩阵转化为向量
x <- c(1:10)
(a <- matrix(x, ncol = 2, nrow = 5, byrow = T))
print(a)
# 创建一个5行2列的矩阵，元素指定“按行填充/读取”
(b <- as.vector(a))         # 将矩阵“转化为向量”
print(b)
c <- matrix(b, nrow=2)
print(c)
# 重新指定行/列数，可改变矩阵大小

(a <- matrix(1:10, nrow = 5, ncol = 2))
(a1 <- rbind(a, c(11,12)))     # 按行的形式、纵向合并
(a2 <- cbind(a, c(11:15)))     # 按列的形式、横向合并
(a3 <- rbind(a, 1))
# 按行合并，短向量元素不足时、循环补齐后合并
(a4 <- cbind(a, 5))
# 按列合并，短向量元素不足时、循环补齐后合并
(a5 <- a[-1, ])      # 删除第一行
(a6 <- a[, -1])      # 删除第一列



## 4) 矩阵的运算
(A <- matrix(c(1:9), ncol = 3, nrow = 3))
(B <- matrix(c(9:1), ncol = 3, nrow = 3))
(C <- 2 * A + B - B / A)
# 四则运算：加减乘除，要求两个矩阵同维、对应位置的元素做运算

(colSums_A <- colSums(A))      # 对矩阵的各列求和
(colMeans_A <- colMeans(A))    # 对矩阵的各列求均值
rowSums(A)                     # 对矩阵的各行求和，直接显示
rowMeans(A)                    # 对矩阵的各行求均值
rowVar(A)                      # 没有rowVar()这样的函数！
## 若要对行/列求“方差、标准差等其他函数运算”，可用apply()函数


t(A)                  # 行/列转置
det(A)                # 方阵求解行列式
(D <- A %*% B)
# 普通矩阵乘法, 要求“左A的列数 ＝ 右B的行数”
A * B                 # 矩阵Hadamard积，对应元素相乘
kronecker(A, B)       # 任意维矩阵的kronecker积，也称为“直积、或张量积”

crossprod(A, B)
# 矩阵“内积”(略)
# 一个行向量乘以一个列向量，称作“向量的内积”(又叫“点积”)，结果是一个数
# 46 ＝ 1*9 + 2*8 + 3*7  ； 28 ＝  1*6 + 2*5 + 3*4   ； 10 ＝  1*3 + 2*2 + 3*1
# 普通矩阵乘法，实质上是基于向量内积定义的算法
t(A) %*% B # %*% 是专门用于矩阵乘法的运算符
# 等价于内积crossprod(A,B)，即 crossprod(A,B) ＝ t(A) %*% B
outer(A,B)
?outer
# 矩阵“外积”(叉积，略)
# 一个列向量乘以一个行向量，称作“向量的外积”(是一种特殊的克罗内克积)，结果是一个矩阵
A %o% B
# 等价于outer(A,B)

(diag_A <- diag(A))          # 矩阵取对角
diag(diag_A)                 # 生成对角阵
diag(3)       # 输入参数为标量，生成单位阵

(Tri <- matrix(1:25,5,5))     # 简化形式、指定行/列
(upper.tri(Tri))              # 返回“逻辑矩阵”
Tri[upper.tri(Tri)] <- 0
# Triangular Part，产生“逻辑索引下标”：上三角元素，设为0
Tri                           # 得到下三角阵

(M <- matrix(c(3:10, 30), ncol = 3, nrow = 3))
solve(M)
# 求解逆矩阵，要求矩阵可逆(行列式不为0)
eigen(M)
# 求解矩阵的特征值和特征向量



## 5) 数组 (略)
x <- c(1:30)
dim1 <- c("A1", "A2", "A3")
dim2 <- c("B1", "B2", "B3", "B4", "B5")
dim3 <- c("C1", "c2")
# 定义数组各维度的名称
(a <- array(x, dim = c(3, 5, 2), dimnames = list(dim1, dim2, dim3)))
# 创建数组，数组维数为3(行、列、页/层)，各维度下标最大值为3、5、2


## 数组索引
a[2, 4, 1]               # 根据位置索引
a[2, 4, 2]
a["A2", "B4", "C1"]      # 根据维度名称索引
dim(a)                   # 查看数组的维度

## 数组维度重置
w <- 1:12
class(w)
dim(w) <- c(2,2,3)       # 将向量w，转化成2×2×3的数组
w
class(w)
as.vector(w)             # 将数组，重置为向量










### 5. 列表(***)：创建、索引、编辑
## 1) 创建列表
# (列表，是特殊的对象集合，其中的元素、可是“向量/矩阵/数组/字符串/其他列表”)
# (每列、各元素/变量/字段/组件的class与length，均可以不同)
# (对象，是类的实例；大多数对象，如函数的返回结果，都体现为列表)
(data <- list(a = c(1, 2, 3, 4), b = c("one", "two", "three"),
              c = c(TRUE, FALSE), d = (1 + 2i)))
summary(data)
# 查看列表的数据结构

g <- "My List"                ;     class(g)
h <- c(25, 26, 18, 39)        ;     class(h)
j <- matrix(1:10, nrow = 5)   ;     class(j)
(mylist <- list(title = g, ages = h, j))
# 创建一个内含多种数据结构的列表
summary(mylist)
# 查看列表的数据结构
# 列表以一种简单的数据结构，组织与重新调用完全不相干的信息
names(mylist)
# 查看“对象中的元素名”



## 2) 列表索引：(5种：下标 or 元素名 + 单括号 or 双括号 ; $元素名)
data[[1]]      ;    class(data[[1]])
# Lt[[下标]]，双重中括号、取出的是“列表元素”(不再含元素/变量名)
data[1]        ;    class(data[1])
# Lt[下标、或下标范围]，单重中括号、取出的是“子列表”
data[["a"]]
# Lt[["元素名"]]，双重中括号(元素名字符、要加引号)、取出的是“列表元素”
data$a
# 同上，索引“列名称为a”的列
# 若列名较长，不引起混淆时、可用缩写
data["a"]
# Lt["元素名"]，单重中括号、取出的是“子列表”
data[[1]][c(2, 4)]
# 更进一步，索引第一列组件的第2与第4个元素



## 3) 列表编辑：赋值语句，或连接函数
data$e <- 5:8    ;    data
# 增加一个新字段/新元素、取名为e，内容为5:8
# 通过赋值语句，新添一个字段/元素/组件/变量
(data1 <- c(data, list(e = c(5, 6, 7, 8))))
# 作对对照，在运行此行语句之前、重新创建一下“以上1)中的原列表data”
# 增加名称为e的新一列：连接函数c()，可连接向量、矩阵、列表、数据框等对象，效果同上
(data2 <- c(data, e = list(c(5, 6, 7, 8))))
class(data2) # list
# 同上
(data3 <- c(data, e = list(c(5, 6, 7, 8)), recursive=T)) # 递归
class(data3)
# 用可选参数“ recursive=T ”、将原列表“压平”——即把列表所有组件的元素提取出来，组合成一个向量。

data$a <- c("one","two", "three", "four")      ;    data
# 更改“列表元素a中的内容”，数值型改为字符型
data$b <- NULL   ;    data
# 赋空值，“删除”一个字段名、及其内容

(unlistd1 <- unlist(data1))
# 解体列表结构，转化为非列表对象、转化为“字符向量”
# 即把列表所有组件的元素提取出来，组合成一个向量，效果类似于 c(data1, NULL, recursive=T)
(c(data1, NULL, recursive=T))
mode(unlistd1)  ; class(unlistd1)  ; typeof(unlistd1)










### 6. 数据框(***)：创建、索引、编辑
## 1) 创建数据框：每列数据类型可不同，但长度必须相同
## 数据框，是一种特殊列表，以“矩阵形式”存放数据
data_iris <- data.frame(Sepal.Length = c(5.1, 4.9, 4.7, 4.6), # column
                        Sepal.Width = c(3.5, 3.0, 3.2, 3.1),
                        Petal.Length = c(1.4, 1.4, 1.3, 1.5),
                        Petal.Width = rep(0.2, 4))
# 向量组成数据框
# iris：鸢(yuan)尾花，Sepal花萼、Petal花瓣
data_iris

(data_matrix <- matrix(1:8, c(4, 2)))     # 创建一个矩阵
(data.frame(data_matrix))
# 将矩阵转化为数据框



## 2) 数据框索引(矩阵、列表：两种方式索引**)
## 列索引
data_iris[, 1]                # 索引第一列
data_iris[[1]]                # 同上，但取出的是元素值
data_iris$Sepal.Length        # 按列的名称索引
class(data_iris$Sepal.Length)
data_iris[["Sepal.Length"]]   # 同上
data_iris[1]
data_iris["Sepal.Length"]     # 按列的名称索引
class(data_iris["Sepal.Length"])     # 取出的是数据框

## 行索引
data_iris[1, ]        # 索引第一行
data_iris[1:3, ]
# 索引第1至第3行

## 单个元素索引
data_iris[1, 1]                   # 索引第一列第一个元素，为一个值
data_iris$Sepal.Length[1]         # 索引Sepal.Length列第一个元素，为一个值
data_iris[["Sepal.Length"]][1]    # 索引Sepal.Length列第一个元素，为一个值
data_iris["Sepal.Length"][1]      # 索引Sepal.Length列第一个元素，但此时却是一个子数据框

## subset函数的条件索引(略)
subset(data_iris, Sepal.Length < 5)
# 按条件索引行
data_iris[data_iris$Sepal.Length < 5, ]
# 同上

## sqldf函数索引(略)
library(sqldf)
mtcars      # A data frame of R with 32 observations on 11 variables
(newdf <- sqldf("select * from mtcars where carb = 1 order by mpg", row.names = TRUE))



## 3) 数据框编辑
(data_iris <- rbind(data_iris, list(5.0, 3.6, 1.4, 0.2)))
# 增加新的样本数据
(data_iris <- cbind(data_iris, Species = rep("setosa", 5)))
# 增加数据集的新属性变量/新字段/新元素，setosa“野/山鸢尾”
(data_iris$Species <- rep("setosa", 5))     ;     data_iris
# 同上，增加数据集的新属性变量/新字段/新元素

## 数据框的删除
data_iris[, -1]     # 删除第一列
data_iris[-1, ]     # 删除第一行

## 数据框列名的编辑
names(data_iris)
# 查看数据框的“列名” ；注意，不是“行名”
names(data_iris)[1] <- "sepal.length"            ;   names(data_iris)
# 采用赋值语句，将数据框第一列列名改为sepal.length(首字母小写)
rownames(data_iris) <- c("one","two","three","four", "five")     ;   data_iris
# 重新命名数据框“行名”
names(data_iris) <- c("x1", "x2", "x3", "x4","x5")    ;   names(data_iris)
# 对数据框里的所有字段/变量，全部按需要、重新命名









### 7. 因子(*)：类别 + 有序
## 1) 创建因子
## 离散型变量，往往用于“分类、或计数”，需要借助因子对象来分析计算
## 因子，可简单视为“附加了额外信息的[向量]”，分为“类别 + 有序”
factor(1:4)
factor(1:4,levels=1:2)
# factor()：生成因子对象，levels指定因子水平
factor(c((1:4),(4:1)),labels=c("A","B","C","D"))
# labels：因子水平的标签，用数字或字母、无本质区别
# 数字1，也仅表示“因子水平1”，并不代表“数值1”

?substring
(f <- factor(substring("statistics", f=1:10, l=1:10), levels = letters))
# 将文本/字符串statistics“逐个拆分”为10个单字符、创建因子向量，水平为26个小写字母
(ff <- factor(f))
# 去除“没有包含在向量中的水平”
f[, drop = TRUE]
# 等价于 f <- factor(ff)，去除“不包含在因子变量中的水平”、结果同上

factor(letters[1:20], labels = "letter")
# 创建因子向量，“水平名称/标签”为letter
factor(letters[1:20])
# 创建因子向量，不设标签名时、此处直接采用“小写字母名”
(z <- factor(LETTERS[7:1], ordered = TRUE))
# 创建“有序的”因子向量


## 创建“水平/level反复重复”的因子：gl(n, k, length)，n为水平数、k为重复次数 (略)
gl(3, 3)          # 生成水平数为3，每个水平重复3次的因子序列
gl(2, 3, labels = c("TRUE","FALSE"))
# 生成水平为“TRUE”和“FALSE”，每个水平重复3次的因子序列
gl(2, 1, 10)      # 生成水平数为2，因子序列长度为10的序列
gl(2, 4, 10)
# 生成水平数为2，每个水平重复4次，序列长度为10的因子序列
gl(3, 5, ordered = TRUE)
# 生成水平数为3，每个水平重复5次的有序因子序列



## 2) 水平的频数统计table()，因子存储方式
status <- c("Poor", "Improved", "Excellent", "Excellent", "Poor", "Excellent")
# 创建“字符向量”
(status.factor <- factor(status, ordered = TRUE))
# 创建有序因子序列，按英文首字母(非文字字面含义)、排序因子水平
levels(status.factor)         # 查看因子的水平
table(status.factor)
# 统计因子水平的频数表(按因子个数，可扩展为“二维列联表、三维表”)

class(status.factor)          # 查看“数据对象的类型”
mode(status.factor)           # “数据存储的大类模式”
typeof(status.factor)         # 因子水平(值)是按“整数”存储的，仅仅是“计数”分类的类别
as.numeric(status.factor)     # 转化为数值型向量


## tapply(), split(), by(), cut()等函数，后续将涉及其应用
## ?tapply







### 8. 表达式与公式
## 1) 表达式
f <- expression(sin(x1)+x2^2)
# 创建“不求值的表达式”，自变量、无须事先定义
# 表达式可求偏导，但不能求根、不能求极值 (须定义函数)
f

x1 <- 12   ;  x2 <- 3.5     # 给定自变量的值
eval(f)                     # 求函数值 # evaluate
D(f, "x1")                  # D()：初等函数求偏导、对x1
D(f, "x2")


## 2) 公式
set.seed(12345)             # 设置随机数的种子数
(p1 <- rnorm(100))            # 生成100个标准正态随机数
(p2 <- runif(100))
model.lm <- lm(p2~p1+I(p1^2)+I(p1^3))
# 公式，用操作符“ ~ ”简示：y ~ x
# 多项式拟合时：同一变量、二次以上的项，放入“ I() ”中
summary(model.lm)












#########################################################
######     Section 1.3： 对象的运算   ######


### 1. 数据对象类型转换
## 1) 类型判断
(M <- matrix(1:12,nrow=3,ncol=4))
mode(M)         # 模式：基本数据类型为“数值型”
class(M)        # 类：构造的对象类型为“矩阵”
typeof(M)       # 类型：细化数据类型为“整型”
### mode，是R存诸数据对象的模式，概念宽泛，如数字逻复、列表、表达式
### mode()：常见模式有 "numeric", "character", "logical","complex", "raw","list", "expression", "name", "symbol" and "function".
### class():类，沿袭面向对象编程的概念而来，In R every 'object' has a mode and a class，如向矩列框
### typeof()：类型，和mode 相似、但比mode分得更精细，从精细度上说：mode < class < typeof
is.matrix(M)    # 判断数据对象类型
is.numeric(M)



## 2) 类型转换
M.vec <- as.vector(M)    # 对象类型转换
M.vec
M.frame <- as.data.frame(M)
M.frame
# 默认：行是“观测点”，列为“元素/变量/字段/组件名”


ff1 <- factor(c(49,81))
ff1
as.numeric(ff1)     # 因子水平“数值标识”，只是分类或计数的代号、不是真正的数值
as.numeric(as.character(ff1))
# 数值型因子、转化为数值型向量：须先转化为字符型，再转换为数值型

ff2 <- factor(c("Shim", "Taylor", "Engel"))
ff2                  # 因子水平为“字符标识”时，按英文字母排序
as.numeric(ff2)      # 将因子水平“字符标识”，转化为对应的数值编码(以英文字母排序)

methods(as)          # 更多类型的转换函数
methods(is)








### 2. 运算符 (三种：数学、比较、逻辑，“数/比/逻”)
## 1) 算术运算
(x <- c(15,16) %% 10)      # %% (模module运算：求余数)
# 其他常见运算符：“ +  -  ×  /  ^ ”
(y <- c(15,45) %/% 4)      # %/% (整除：除法的整数部分)
(x = pi*1:3^2)
# 生成向量运算符“ : ”的优先级，高于乘法运算*、但低于幂运算^

y <- matrix(c(1:9), ncol=3)
z <- matrix(c(11:19), ncol=3)
z
z[lower.tri(z)] <- 0
z                          # 上三角矩阵
y*z                        # “矩阵对应元素”相乘：Hadmad积
y %*% z                    # 矩阵普通乘法：%*%
kronecker(y,z)
# 矩阵的“kronecker积”乘法
# 若y为(m × n)维，z为(p × q)维，则新矩阵维度：(mp × nq)



## 2) 比较运算符
M <- c("A","B")
m <- c("a","b")
M == m
# 单个元素比较；类似的，“>”、“>=”、"<"、"<="、“!=”

## 对象整体比较
identical(M,m)
all.equal(M,m)

identical(y,z)
all.equal(y,z)                   # 若不完全相等，返回平均相对差异值、或不匹配的字符数



## 3) 逻辑运算符“与、或、非”：&、|、!
## 异或运算函数 xor(x, y) ：不同、为1 (T) ，相同、为0 (F)
xor(T, F)
xor(1, 0)
xor(T, T)






### 3. 运算函数
## 1) 向量运算函数
x <- c(1,5,4,7,9)
sum(x)
mean(x)
sd(x)
median(x)
sort(x)        # 从小到大、排序 (参数decreasing，控制升/降序)
rev(x)         # 对原顺序、逆序排列（倒序）
sort(x, decreasing = T) # 降序 ！= 对原序列逆序
order(x)       # 对于升序排列的数在原始序列中的位置
# 升序排列元素、“在x中的下标”，即“sort(x)中对应排列的元素”、在向量x中的位置

append(x, 2:3, after=2)
# 在x的“指定下标位置”处、添加新的向量元素2:3

x <- runif(100,0,20)
y <- runif(100,0,20)
x > y              # 得到比较的逻辑结果
sum(x > y)
# 求和“逻辑结果为真的个数”



## 2) 矩阵运算函数
(A <- matrix(1:9,ncol=3))
t(A)           # Transpose：普通“矩阵转置”
aperm(A,c(2,1))                 # 数组"维度转换"函数，效果同上(略)

(A <- matrix(sample(1:100, 16), ncol=4))
solve(A)       # 方阵“求逆”；solve(a, b)，可解线性方程组“ax = b”

nrow(A)        # 求矩阵行数
ncol(A)

B <- matrix(1:8,ncol=4)  ;  B
(C <- matrix(8:1,ncol=4))
rbind(B,C)          # rbind()：纵向按行合并
cbind(B,C)          # cbind()：横向“按列合并”





## 3) apply函数族 (避免代码重复操作，数值分析批量运算)
## a) apply函数(主要用于“矩阵”：apply(m, d, g))
(x <- matrix(1:20, ncol = 4))
apply(x, 1, mean)      # 计算各行的均值
apply(x, 2, sd)        # 计算各列的标准差
sd(1:5)                # 验证：第一列的标准差

(x <- runif(10,-1,1))  # runif 函数用于生成服从均匀分布的随机数； runif(n,min=a,max=b)
(y <- rnorm(10,0.5,1))
(xy <- cbind(x,y))
class(xy)
apply(xy,1,sum)      # 对矩阵的行，按行求和
rowSums(xy)          # 同上
apply(xy,2,max)      # 对矩阵的列，按列求最大值




## b) tapply函数 ( 用于“依因子对象分类”的“向量”：tapply(x, f, g) )
f1 <- factor(rep(1:4,length=14),levels=1:5,labels=c("A","B","C","D","E"))
# 产生长度为14的因子对象，5个因子水平的标签、设为ABCDE
f1
(x2 <- c(1:14))
tapply(x2,f1,sum)
# f1是“用于分类的因子对象”，其长度与“向量x2的长度”一致、以便“一一对应”
# 先依f1、对x2元素进行分组，每组应对一个因子水平，对分组后x2的子向量、应用函数sum
# 如A因子水平对应的子向量元素为：1, 5, 9, 13
# 默认返回简化形式，一个数组/向量(形如table)，而不是列表list
aggregate(x2, by=list(f1), sum)                   # 结果类似，同上
by(x2, f1, sum)
# aggregate()、by()：可将tapply()函数对象为向量的限制，扩展到“数据框”
tapply(x2, f1, sum, simplify=FALSE)
# 不采用简化形式，返回一个列表

# ***
# 创建一个示例向量
values <- c(12, 25, 18, 30, 22, 35)
# 创建一个分组因子
groups <- factor(c("A", "B", "A", "B", "A", "B"))

# 计算每个组的平均值
group_means <- tapply(values, groups, mean)
print(group_means)

# 计算每个组的总和
group_sums <- tapply(values, groups, sum)
print(group_sums)

# 自定义函数：计算每个组的最大值与最小值之差
range_diff <- function(x) {
  return(max(x) - min(x))
}

# 应用自定义函数
group_range_diffs <- tapply(values, groups, range_diff)
print(group_range_diffs)
# ***


## c) lapply函数 (主要对“列表/数据框”对象、进行运算)
(L1 <- list(a=1:20, b=runif(30,-2,5), d=matrix(c(1:20),ncol=4)))
lapply(L1,quantile)
# 对列表的“各个元素/字段/组件”，分别求分位数函数运算 (矩阵也是一种向量)



## d) sapply函数 (lapply的特殊形式)
sapply(L1,quantile,simplify=FALSE,use.names=FALSE)   # 返回一个列表，同lapply
sapply(L1,quantile,simplify=TRUE,use.names=FALSE)    # 返回矩阵形式的结果

(L2 <- list(c("a", "b", "c"), c("A", "B", "C")))
sapply(L2, paste, 1:3, sep="", simplify = TRUE)
# 列表list中的每个元素、与数字1:3连接，输出结果为矩阵
# 此处“1:3、sep”,均为paste的参数
sapply(L2, paste, 1:3, simplify = F)
# 同上，但输出结果为列表
# 此时，间隔符sep、默认为空格


## e) mapply()：sapply()的多变量版本，对列表、或多个变量/字段的每个元素运行FUN (略)
mapply(rep, times = c(2, 5), MoreArgs = list(x = 1:2))
# 重复生成列表，重复次数times=c(2, 5)，结果为一个列表(不可降维时)
# MoreArgs: a list of other arguments to FUN
sapply(list(x = 1:2), rep,  times = c(2, 5))
# 比较：sapply()仅对列表中的每列元素、作fun运算，但对列表本身、不作整体运算
mapply(rep, times = c(2, 2), MoreArgs = list(x = 1:2))
# 重复生成列表，重复次数times=c(2, 2)，结果为一个矩阵(可降维时，默认降维)
mapply(function(x, y) seq_len(x) + y,
       # 自定义一个函数，其中seq_len()、为返回给定长度的自然数序列
       c(a =  1, b = 2, c = 5),
       # 依次取第一个变量/列表x的各个元素取值，作seq_len()运算：1 ;  1:2  ;  1:5
       c(A = 10, B = 0, C = -10))
# 依次取第二个变量/列表y的各个元素取值
# 3次分别为：1 + 10  ;  1:2 + 0  ;  1:5 + (-10)











#########################################################
######     Section 1.4：常用命令   ######


### 1. 工作目录与R内存
##  1) 设置工作路径
getwd()
setwd('I:/R learning/3 Finance with R')             # 斜杠
setwd('I:\\R learning\\3 Finance with R')           # 双反斜杠

## 2) R内存
memory.size(NA)
memory.limit()
memory.size(FALSE)
memory.size(TRUE)
memory.size(4095)        # 查看与增大工作内存





### 2. 加载与保存
## 1) R包
library(quantmod)       # 加载quantmod的包
require(quantmod)
# 同上
search()                # 查看当前空间中已存在的包


## 2) R对象 (略)
(x <- rnorm(10))
(y <- matrix(1:20, nrow=5))
(z <- paste("x", 1:10, sep=''))
ls()                # 查看当前空间中已存在的对象
save.image()        # 保存工作空间所有对象，生成“ .RData”文件
save(x,y,file="S.RData")
# 仅保存部分“指定的对象”
load(file="S.RData")


## (3) R图片 (略)
jpeg(file="Saveplot1.jpeg")              # jpeg格式
# 打开绘图设备、即一个文件，然后在该文件中绘图
data(iris)
plot(iris)
dev.off()           # 关闭绘图设备

postscript(file="Saveplot2.eps")         # ps格式
plot(iris)
dev.off()





### 3. 显示命令
head(iris)
tail(iris)

library(car)
some(iris)
# 显示“任意一些行”，some是R包car中的函数

D <- seq(1:3)
D
print(D)
(D <- seq(1:3))
# 显示全部，三种方式：直接用“对象名称”、“print( )”、“(对象)”

E1 <-3.1415926535
E2 <-3.1415926535
(E1.r <- round(E1,digits=4))            # 四舍五入，小数点保留四位
E1.r*1000000

op <- options()
# 先保存当前全局选项的设置 (关于R计算与显示的方式)
options(digits=4)    ;    E2
# 显示四位数字，但实质上“未作四舍五入”
E2*1000000
options(op)          # 否定之否定，还原原有的选项设置






### 4.挂接命令
df <- data.frame(name=c("ZhangSan","XiaoHong","LiSi","XiaoLan"),
                 sex=c("M","F","M","F"),age =c(20,21,19,20),weight=c(110,90,128,102))
attach(df)
# 将“数据框/列表中的变量/元素”，直接“挂接到内存”
mean(age)
# 直接调用元素/字段名 (不再需用数据框/列表名引用)，作为对象来运算
detach(df)
mean(df$age)

library(quantreg)
detach("package:quantreg")
# 去掉挂接、释放内存，同时避免“不同包、相同函数的冲突”



