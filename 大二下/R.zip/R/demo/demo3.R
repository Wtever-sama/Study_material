############   ??????  ????R?????Ĵ?ͳ????   ###########



#########################################################
######  Section 3.1?? ͳ?Ʒ???   ######



### 0. ??ʼ??׼??
    ## 1) ???ù???·?????????????ռ??е????ݶ???
setwd('I:/R learning/3 Finance with R/data and R files/CH 3')
rm(list = ls())                   



#####   3.1.1  ??Ԫ?ع?????    #####

### 1. ??ȡExcel????
    ## method 1
dat.csv <- read.csv(file='MacEcoData-csv.csv')        
head(dat.csv)    ;    class(dat.csv)


    ## method 2????openxlsx
library(openxlsx)
dat <- read.xlsx("MacEcoData.xlsx", 'data1')
head(dat)    ;    class(dat)


    ## method 3????readxl
library(readxl)
dat <- read_excel(path='MacEcoData.xlsx', sheet='data1')
head(dat)    ;    class(dat)




### 2. ????????
dat.log <- log(dat)       
dim(dat.log)
names(dat)   
names(dat.log)            




### 3. lm()???????��?????ģ??
model.lm <- lm(M2~., data=dat.log)    
class(model.lm)    ;    mode(model.lm)
print(model.lm)
summary(model.lm)





### 4. ????ģ??
    ## 1) ???????????????ع????? (?Խ?)
kappa(dat.log)                      
DAAG::vif(model.lm)                  
    

    ## 2) ??Ԫ?ع??Ĳв?????ͼ
par(mfrow=c(2,2))
plot(model.lm)
par(mfrow=c(1,1))




### 5. ??ȡģ????Ϣ
names(model.lm)
    ## 1) ??ȡ???ع?ϵ????
(coefs.lm <- coef(model.lm))         
(coefs.lm <- model.lm$coefficients)


    ## 2) ????ֵ
(fit.lm <- predict(model.lm, se.fit=TRUE))    
 

    ## 3) ?в?
(res.lm <- resid(model.lm))          


    ## 4) R square????sigma
mode(summary(model.lm))    ;   class(summary(model.lm))
names(summary(model.lm))
(R2 <- summary(model.lm)$r.squared)
(sigma <- summary(model.lm)$sigma)



### 6. ??Ԥ??
    ## 1) Ԥ???Ա?��????????ֵ
tt <- 1:10                                        
CPI.hat <- dat$CPI[nrow(dat)]*1.05^tt           
ir.hat <- dat$ir[nrow(dat)]*1.00^tt                
GY.hat <- dat$GY[nrow(dat)]*1.05^tt                
NewData <- data.frame(CPI=CPI.hat, ir=ir.hat, GY=GY.hat)    



    ## 2) Ԥ??
M2.hat <- predict(model.lm, newdata=log(NewData), interval='prediction')     
M2.hat
matplot(M2.hat, lty=c(1,2,2), type='l', xlab='ʱ??', ylab = "log(M2)??Ԥ??ֵ")     











##### 3.1.2  ?𲽻ع?????:?ʲ???ծ?ʵ?Ӱ??????̽??  #####

### 1. ??д.xlsx??Excel????
    ## method 1????openxlsx
library(openxlsx)
dat <- read.xlsx("MicEcoData.xlsx", 'stepReg')


    ## ????2
library(readxl)
dat <- read_excel(path='MicEcoData.xlsx', sheet='stepReg')


head(dat)
names(dat) <- c('y', paste('x', 1:7, sep=''))                        
head(dat)



### 2. ????????lm( )   
model.lm <- lm(y~.,data=dat)
summary(model.lm)



### 3. ?𲽻ع?Ѱ??step()
model.step <- step(model.lm)          
summary(model.step)










######  Section 3.2?? ??��???÷???   ######


###  ??׼??̬??Logit????ֵ?ֲ??ıȽ?
### 1. ??????????????????x
x <- seq(-5, 5, length=100)      



### 2. ???㲻ͬ?ֲ????ۻ??????ֲ?CDF????
    ## 1) ??̬?ֲ?
(CDF.norm <- pnorm(q=x, mean=0, sd=1))    
   

    ## 2) logitstic?ֲ?
(CDF.logit <- plogis(q=x, location=0, scale=1))    


    ## 3) extreme/??ֵ?ֲ?
?pextreme   
pextreme <- function(x) 1-exp(-exp(x))      
(CDF.extr <- pextreme(x))



### 3. ?Ƚϡ??ۻ????ʷֲ???
par(mfrow=c(1,1))
plot(c(x,x,x), c(CDF.norm, CDF.logit, CDF.extr), type='n', xlab='x', ylab='CDF', main="?????ۻ????ʷֲ??ıȽ?")
lines(x, CDF.norm, lty=1, lwd=2, col="green3")         
lines(x, CDF.logit, lty=2, lwd=2, col = "blue")
lines(x, CDF.extr, lty=3, lwd=2, col = "red")
abline(h=0.5, lty=20)
abline(v=0, lty=20)
legend('topleft', legend=c('??׼??̬?ֲ?', '?߼??ֲ?', '??ֵ?ֲ?'), lty=c(1,2,3), lwd=c(2,2,2), 
       col=c(3, 4, 2), bty="n")




### ???䣺glm()????ʾ??
# glm(forumla, family=binomial(link="logit"), data=dfname)









###### section 4: ?Ż??????뷽??



### 1. ??2-6?????⡰?????Է??̵ĸ??????ȼ??????⡰?????Է??̵?ƽ????????????Сֵ
    ## 1) ????һ??????ծȯ?۸?????ʧ????f(r)
f <- function(r, p, Cs){
    n <- length(Cs)
    tt <- 1:n
    loss <- p - sum(Cs/((1+r)^tt))
    loss
}



    ## 2) ֱ????????uniroot()
Cs <- c(2000, 2000, 2500, 4000)
P <- 7704
(irr1 <- uniroot(f, c(0,1), p=P, Cs=Cs))           



    ## 3) ????һ???????Ժ??????????Ż????⡱??optimize()
g <- function(r, p, Cs) {f(r, p, Cs)^2}   
(irr2 <- optimize(g, c(0,1), p=P, Cs=Cs))           



    ## 4) ?Ƚ?��?ַ???  (????)
rs <- seq(0, 1, length=100)
fval <- gval <0- numeric(length(rs))
for (i in seq_along(rs)){
    fval[i] <- f(r=rs[i], p=P, Cs=Cs)
    gval[i] <- g(r=rs[i], p=P, Cs=Cs)
}

par(mfrow=c(2,1)
, mar=c(2, 4, 1, 1))
plot(rs, fval, type='l', xlab='r', ylab='f')
abline(h=0, lty=2)
abline(v=irr1$'root', col="red")
plot(rs, gval, type='l', xlab='r', ylab='g')
abline(h=0, lty=2)
abline(v=irr2$'minimum', col="green3")
par(mfrow=c(1,1))






## 3. ??2-8
(rs[which.min(abs(fval))])
(rs[which.min(gval)])???Ƚ϶??ι滮??OLS 
# (1) ????????
beta <- c(5, 2)
sigma <- 1
n <- 10000
set.seed(163)
eps <- rnorm(n, mean=0, sd=1)
x <- runif(n, min=-10, max=10)
y <- beta[1] + beta[2]*x + sigma*eps




# (2) ͨ?????Իع飬?õ???????��
model.lm <- lm(y~x)
(coef.OLS <- coef(model.lm))



# (3) ???⡰???ι滮????optim()???? 
lossQuad <- function(betaHat, x, y){
    sum((y-betaHat[1]-betaHat[2]*x)^2)
    }
optim(par=coef.OLS, fn=lossQuad, y=y, x=x)           
?optim
optim(par=c(5, 2), fn=lossQuad, y=y, x=x)
optim(par=c(80, 45), fn=lossQuad, y=y, x=x)












