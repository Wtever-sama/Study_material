# %%
#T1-------------------------------------------------
#请自行编写单变量的“描述性统计及绘图函数”，要求以列
#表形式输出其均值、中位数、标准差、最大/小值、偏度、峰度、
#JB统计量及其伴随概率值 [单位根检验（选） 、arch效应检验
#（选）] 的结果（保留三位小数），同时可按需要选择性输出该
#变量的正态QQ图、密度分布图及其与之相应的理论正态分布图的
#对比图。
#请采集近3年的日度深证成指、近10年月度CPI指数的数据，
#以实证分析深成指对数收益率、CPI同比变化率的描述性统计及
#探析其分布特征。
setwd("/Users/wtsama/Documents/code/code2/R/data/2assignment/")

rm(list = ls())

cpi_data <- read.csv(file = "月度数据_filtered.csv",
                     header = TRUE, fileEncoding = "UTF-8", row.names = 1)
class(cpi_data) # data.frame

is_num_cpi <- sapply(cpi_data, is.numeric) # bool
num_cpi <- cpi_data[, is_num_cpi] # 筛选是数值的列
num_cpi
# %%
# 标准化处理
data_zscore <- scale(num_cpi)
data_zscore_lst <- lapply(seq_len(data_zscore),
                          function(i) as.numeric(data_zscore[i, ]))
data_zscore_lst

# 手动计算
row_zscores <- function(x) (x - mean(x)) / sd(x)
row_zscore_list <- lapply(seq_len(nrow(cpi_data)),
                          function(i) row_zscores(as.numeric(num_cpi[i, ])))
row_zscore_list

class(num_cpi) # data.frame
# 最小值
min_cpi <- apply(num_cpi, 1, min) # 获取每一行的最小值;列：2
min_cpi
as.list(min_cpi)
# 最大值
max_cpi <- apply(num_cpi, 1, max)
as.list(max_cpi)
# CPI 均值
library(psych)
row_mean_cpi <- rowMeans(num_cpi)
result_mean <- as.list(row_mean_cpi)
result_mean
# CPI中位数
row_median_cpi <- apply(num_cpi, 1, median)
result_median <- as.list(row_median_cpi)
result_median
# skewness:偏度系数
library(moments)
skw_cpi <- apply(num_cpi, 1, skewness)
as.list(skw_cpi)
# 峰度系数
kurtosi_cpi <- apply(num_cpi, 1, kurtosi)
as.list(kurtosi_cpi)

# JB统计量计算
# library(moments)

jarque_bera_cpi <- function(x) {
    n <- length(x)
    s <- skewness(x)
    k <- kurtosis(x)
    jb <- (n / 6) * (s^2 + ((k - 3)^2) / 4)
    return(jb)
}

jb_cpi <- apply(num_cpi, 1, jarque_bera_cpi)
as.list(round(jb_cpi, 3))

#  JB 统计量的伴随概率值
library(moments)
jb_pvalue <- apply(num_cpi, 1, function(x){
    test_res <- jarque.test(x)
    return(test_res$p.value)
})
as.list(round(jb_pvalue, 3))

#变量的正态QQ图
library(ggplot2)

colnames(num_cpi)

row_1 <- as.numeric(num_cpi[1, ])
names(row_1) <- colnames(num_cpi)
df <- data.frame(month = names(row_1),
    value = row_1
)

p_1 <- ggplot(df, aes(sample = value)) +
    stat_qq() +
    stat_qq_line() +
    labs(title = "Consumer Price Index(2016-2025)",
         x = "Theoretical Quantiles",
         y = "Sample Quantiles") +
    theme_minimal()
print(p_1)
ggsave("cpi_qq_plot.png", plot = p_1, width = 8,height = 6, dpi = 300)

# 密度分布图
library(ggplot2)
library(moments)

mean_val <- mean(row_1)
sd_val <- sd(row_1)

x_seq <- seq(min(row_1), max(row_1), length.out = 100)
normal_density <- data.frame(
    x = x_seq,
    y = dnorm(x_seq, mean = mean_val, sd = sd_val)
)
p_dens <- ggplot(df, aes(x = value)) +
    # 实际数据的密度曲线
    geom_density(color = "blue", linewidth = 1, fill = "lightblue", alpha = 0.5) +
    # 理论正态分布曲线
    geom_line(data = normal_density, aes(x = x, y = y),
              color = "red", linetype = "dashed", linewidth = 1) +
    labs(title = "CPI Density Plot",
        x = "Value",
        y = "Density")
    theme_minimal() +
    scale_y_continuous(expand = c(0, 0)) +
    scale_x_continuous(expand = c(0, 0))

print(p_dens)
ggsave("CPI密度分布与理论正态分布对比.png", width = 8, height = 6, dpi = 300)

# %%
# CPI同比变化率
num_cpi
num_cpi_t <- as.data.frame(t(num_cpi))
colnames(num_cpi_t) <- gsub("居民消费价格指数","",rownames(num_cpi))
head(num_cpi_t)
cpi_change_percentage <- as.data.frame(lapply(num_cpi_t, function(x) {x - 100}))
head(cpi_change_percentage)
# 基础绘图
mpl <- matplot(cpi_change_percentage, type = "l", lty = 1, col = rainbow(ncol(cpi_change_percentage)),
        xaxt = "n", xlab = "时间", ylab = "同比变化率 (%)", main = "CPI 各分项同比变化率")

axe <- axis(1, at = 1:nrow(cpi_change_percentage), labels = rownames(cpi_change_percentage), las = 2)
leg <- legend("topright", legend = colnames(cpi_change_percentage),
       col = rainbow(ncol(cpi_change_percentage)), lty = 1)

# %%
# 深证成指
library(openxlsx)
setwd("/Users/wtsama/Documents/code/code2/R/data/2assignment/")
share_data <- read.xlsx("K线导出_399001_日线数据.xlsx")
close_price <- share_data[ , "收盘价"]
df <- data.frame(close_price)
# %%
library(ggplot2)
library(moments)
plot_share <- ggplot(df, aes(sample = as.numeric(close_price))) +
            stat_qq() +
            stat_qq_line() +
            labs(title = "399001",
                 x = "Theoretical Quantiles",
                 y = "Sample Quantiles") +
            theme_minimal()
print(plot_share)
#ggsave("深证成指Q-Q图.png", width = 8, height = 6, dpi = 300)
# %%
# 计算对数收益率
library(bizdays) # The following object is masked from ‘package:stats’:offset
start_date <- as.Date("2022-05-09")
n_days <- nrow(share_data)
print(n_days)
date$交易时间 <- seq.Date(from = start_date, by = "day", length.out = n_days)
date$交易时间
colnames(share_data)
log_return <- diff(log(close_price), lag = 1)
log_return_df <- data.frame(Date = tail(date,
                                        length(log_return)),
                            Log_Return = as.numeric(log_return))

# %%
#

