qnorm(0.975, 0, 1)
z <- 5^0.5*(8.15-8)/0.2
z
pnorm(2, 0, 1)
2*(1-pnorm(2.795, 0, 0.4))

c <- qnorm(1.95 / 2, 0, 1)
a <- 10^0.5

x <- (482 + 493 + 457 + 471 + 510 + 446 + 435 + 418 + 394 + 469) / 10
x
sigma <- 30
x1 <- -c / a * sigma + x
x1
x2 <- c / a * sigma + x
x2
l <- function(mu) a * (x - mu) / c
l
a / c


x_2 <- qchisq(0.025, 9, lower.tail = T)
x_2
x_2_1 <- qchisq(0.975, 9, lower.tail = T)
x_2_1
list <- c(482 , 493 , 457 , 471 , 510 , 446 , 435 , 418 , 394 , 469)
s <- var(list)
s1 <- 3 * s^0.5 / x_2^0.5
s1
s2 <- 3 * s^0.5 / x_2_1^0.5
s2

c <- qnorm(1.95 / 2 , 0, 1)
c
x_bar <- 82
y_bar <- 76
sigma_s <- 64
sigma_s_2 <- 49
n1 <- 10
n2 <- 15
sigma_s <- 56.5
sigma_s_2 <- 52.4
l <- -c * (sigma_s / n1 + sigma_s_2 / n2)^0.5 + (x_bar - y_bar)
l
r <- c * (sigma_s / n1 + sigma_s_2 / n2)^0.5 + (x_bar - y_bar)
r
m <- c * (sigma_s / n1 + sigma_s_2 / n2)^0.5
m
t_s <- qt(0.025, n1 + n2 -2)
t_s
t_m <- qt(0.975, n1 + n2 - 2)
t_m
l <- -t_m * (((n1 - 1) * sigma_s + (n2 - 1) * sigma_s_2) /
               ((n1 -1) * (n2 - 1) * (n1 + n2- 2)))^0.5 * (n1 + n2)^0.5 +
  x_bar - y_bar
l
r <- -t_s * (((n1 - 1) * sigma_s + (n2 - 1) * sigma_s_2) /
               ((n1 -1) * (n2 - 1) * (n1 + n2- 2)))^0.5 * (n1 + n2)^0.5 +
  x_bar - y_bar
r

matter1 <- sigma_s * (n1 - 1)
matter1
matter2 <- sigma_s_2 * (n2 - 1)
matter2

t_m / 5
x_bar - y_bar
t_s / 5

?optimise
f <- function(c) (576 + 686 / c)^0.5 * (0.1 + c / 15)^0.5
res <- optimize(f, c(0, 100), maximum = F)
res[2]
6 - t_m * 14.35211 / 5
6 - t_s * 14.35211 / 5
c <- sigma_s_2 / sigma_s
c
res <- 14.91085
l <- x_bar - y_bar - t_m / 5 * res
l
r <- x_bar - y_bar - t_s / 5 * res
r
# (3)
s0_s <- sigma_s / n1 + sigma_s_2 / n2
s0_s
s0 <- sqrt(s0_s)

l <- s0_s^2 / ((sigma_s^2 / ((n1 -1) * n1^2)) + (sigma_s_2^2 / ((n2 -1) * n2^2)))
l

x_bar <- 82
y_bar <- 76
left <- x_bar - y_bar - qt(0.975, 19) * s0
left
right <- x_bar - y_bar + qt(0.975, 19) * s0
right

# (4)
left <- sigma_s / (sigma_s_2 * qf(0.975, n1 - 1, n2 - 1))
left
right <- sigma_s / (sigma_s_2 * qf(0.025, n1 - 1, n2 - 1))
right

## 17
# (1)

x <- c(16.2, 16.4, 15.8, 16.7, 15.6, 15.8)
s1 <- var(x)
s1

# 观测频数
x <- c(315, 108, 101, 32)
# 进行卡方拟合优度检验
result <- chisq.test(x, p = c(9, 3, 3, 1) / 16)
# 输出结果
print(result)

# 设置F分布的参数
df1 <- 5  # 分子自由度
df2 <- 10 # 分母自由度

# 生成F分布的x值
x <- seq(0, 5, by = 0.01)

# 计算F分布的概率密度函数值
y <- df(x, df1, df2)

# 绘制F分布的概率密度函数图
plot(x, y, type = "l", col = "blue", lwd = 2,
     main = paste("F Distribution (df1 =", df1, ", df2 =", df2, ")"),
     xlab = "x", ylab = "Density")

# 添加网格线
grid()

x <- qf(0.95, 5, 10)

choose(10, 5)*0.2^5*0.8^5 + choose(10, 6) * 0.2^6 * 0.8^4
+ choose(10, 7) * 0.2^7 * 0.8^3 + choose(10, 8) * 0.2^8 * 0.8^2
+ choose(10, 9) * 0.2^9 * 0.8
+ choose(10, 9) * 0.2^10

choose(10, 4) * 0.4^4 * 0.6^6
+ choose(10, 3) * 0.4^3 * 0.6^7
+ choose(10, 2) * 0.4^2 * 0.6^8
+ choose(10, 1) * 0.4^1 * 0.6^9
+ choose(10, 0) * 0.4^0 * 0.6^10

c <- qnorm(0.025, 0, 1) / (-2)
c
x1 <- (c + 6 - 6.5) * 2
x2 <- (-c - 0.5) * 2
x1
x2
pnorm(x1,0,1)- pnorm(x2, 0, 1)
qnorm(1-0.05, 0, 1)

s <- c(seq(0.2,0.9,length.out = 8))
lambda <- c(0.05, s)
lambda
x <- 60*lambda
y <- qpois(0.95, x)
y
beta <- ppois(y,x)
beta
par(mar=c(4,4,2,2))
plot(x,beta)

lambda <- 0.1
x_bar <- qnorm(0.95,0,1) * lambda^0.5 * 30^0.5 + lambda
x <- x_bar * 30
x_bar

qnorm(0.025, 0 ,1)
x <- c(14.7,15.1,14.8,15,15.2,14.6)
fenmu <- (var(x))^0.5 / 6^0.5
u <- (mean(x) - 15) / fenmu
u

x <- c(99.3,98.7,100.5,101.2,98.3,99.7,102.1,100.5)
chs <- 8*var(x)/1.2^2
chs
chs1 <- qchisq(0.025,8)
chs2 <- qchisq(0.975,8)
chs1
chs2

x <- c(20.5,18.8,19.8,20.9,21.5,19.5,21,21.2)
y <- c(17.7,20.3,20,18.8,19,20.1,20,19.1)
sw <- ((7*var(x) + 7*var(y))/(8+8))^0.5
fenmu1 <- (1/8 + 1/8)^0.5
t <- (mean(x) - mean(y))/(sw*fenmu1)
t
qt(0.975,14)

x <- c(1.32,1.55,1.36,1.4,1.44)
kaf <- 4*var(x) / 0.048^2
kaf
qchisq(0.975, 4)
15.46/9.66
qf(0.95,13,11)


qchisq(0.95, 5)
x <- exp(-1)
fenmu <- x * 100
kafang <- ((35 - fenmu)^2 + (40 - fenmu)^2 + 2 * (19 - 50 * x)^2 +
           6 * (3 - 50 / 3 * x)^2 + 24 * (2 - 25 / 6 * x)^2 +
          120 * (1 - 5 / 6 * x)^2) / fenmu
kafang

x1 <- (121 - 300 * (1 - exp(-0.5)))^2 / (300 * (1 - exp(-0.5)))
x1
x2 <- (78 - 300 * (exp(-0.5) - exp(-1)))^2 / (300 * (exp(-0.5) - exp(-1)))
x2
x3 <- (43 - 300 * (exp(-1) - exp(-1.5)))^2 / (300 * (exp(-1) - exp(-1.5)))
x3
x4 <- (58 - 300 * exp(-1.5))^2 / (300 * exp(-1.5))
x4
x1 + x2 + x3 + x4
qchisq(0.95, 3)

g1 <- c(8, 5, 7, 4)
g2 <- c(6, 10, 12, 9)
g3 <- c(0, 1, 5, 2)
mean <- (mean(g1) + mean(g2) + mean(g3)) / 3
m1 <- mean(g1)
m2 <- mean(g2)
m3 <- mean(g3)
ssa <- 4 * ((m1 - mean)^2 + (m2 - mean)^2 + (m3 - mean)^2)
f <- function(x) x^2
sse <- sum((g1 - m1)^2) + sum((g2 - m2)^2) + sum((g3 - m3)^2)
sse

all_data <- c(g1, g2, g3)
sst <- sum((all_data - mean)^2)
sst

g1 <- c(7.3,8.3,7.6,8.4,8.3)
g2 <- c(5.4,7.4,7.1,6.8,5.3)
g3 <- c(7.9,9.5,10,9.8,8.4)
m1 <- mean(g1)
m2 <- mean(g2)
m3 <- mean(g3)
mean <- (mean(g1) + mean(g2) + mean(g3)) / 3
ssa <- 5 * ((m1 - mean)^2 + (m2 - mean)^2 + (m3 - mean)^2)
sse <- sum((g1 - m1)^2) + sum((g2 - m2)^2) + sum((g3 - m3)^2)
sst <- sum((c(g1,g2,g3) - mean)^2)
ssa
sse
sst
fa <- 2
fe <- 12
ft <- 14
msa <- ssa / fa
mse <- sse / fe
F <- msa / mse
msa
mse
1 - pf(q = F, 2, 12, lower.tail = F)
?pf
s2 <- (var(g2))^0.5
m2 + qt(0.975, 4) * s2 / 5^0.5

# chapter8.1 T8
g1 <- c(20, 16.8, 17.9, 21.2, 23.9, 26.8, 22.4)
g2 <- c(24.9, 21.3, 22.6, 30.2, 29.9, 22.5, 20.7)
g3 <- c(16, 20.1, 17.3, 20.9,22, 26.8, 20.8)
g4 <- c(17.5,18.2, 20.2,17.7, 19.1, 18.4, 16.5)
g5 <- c(25.2, 26.2, 26.9, 29.3, 30.4, 29.7, 28.2)
m1 <- mean(g1)
m2 <- mean(g2)
m3 <- mean(g3)
m4 <- mean(g4)
m5 <- mean(g5)
mean <- (mean(g1) + mean(g2) + mean(g3) + mean(g4) + mean(g5)) / 5
ssa <- 5 * ((m1 - mean)^2 + (m2 - mean)^2 + (m3 - mean)^2 +
  (m4 - mean)^2 + (m5 - mean)^2)

sst <- sum((c(g1,g2,g3,g4,g5) - mean)^2)
sse <- sst - ssa
ssa
sse
sst
fa <- 4
ft <- 5 * 7 - 1
fe <- ft - 4
msa <- ssa / fa
mse <- sse / fe
F <- msa / mse
msa
mse
F
1 - pf(F, fa, fe)
qf(0.95, 4, 30)

all <- cbind.data.frame(g1, g2, g3, g4, g5)

f <- function(x) (var(x))^0.5
s <- apply(all, 2, f)

m_g <- apply(all, 2, mean)

l <- m_g - s * qt(0.975, 6) / 6^0.5
r <- m_g + s * qt(0.975, 6) / 6^0.5
r

# chapter 8.2 T3
bar_y_i <- c(6.3,6.2,6.7,6.8,6.5,7,7.1)
s_i <- c(0.81,0.92,1.22,0.74,0.88,0.58,1.05)
fse <- function(x) 3 * x^2
se <- sum(sapply(s_i, fse))
y_bar <- mean(bar_y_i)
y_bar
fsa <- function(x) (x - y_bar)^2
sa <- 4 * sum(sapply(bar_y_i, fsa))
st <- sa + se
fa <- 6
fe <- 21
ft <- 27
msa <- sa / fa
mse <- se / fe
F <- msa / mse
se
sa
st
msa
mse
F
1 - pf(F, fa, fe)
#T3-2
s <- (st * 1 / 27)^0.5
y_bar + qt(0.95, 3) * s / 2


#T4
# 生成示例数据（不等重复数）
group1 <- c(7.6,8.2,6.8,5.8,6.9,6.6,6.3,7.7,6.0)
group2 <- c(6.7,8.1,9.4,8.6,7.8,7.7,8.9,7.9,8.3,8.7,7.1,8.4)
group3 <- c(8.5,9.7,10.1,7.8,9.6,9.5)

# 组合数据框
df <- data.frame(
  value = c(group1, group2, group3),
  group = factor(rep(1:3, times = c(length(group1), length(group2), length(group3))))
)
df
# 1. 方差齐性检验
leveneTest(value ~ group, data = df)

# 2. 单因素ANOVA
anova_result <- aov(value ~ group, data = df)
summary(anova_result)

# 3. 多重比较（以Tukey为例）
tukey_result <- TukeyHSD(anova_result)
print(tukey_result)
plot(tukey_result)  # 可视化置信区间
# 3.1 以Scheffé为例
# 构建ANOVA模型

model <- aov(value ~ group, data = df)
# 加载multcomp包
library(multcomp)
# 执行Scheffé检验
scheffe_result <- glht(model, linfct = mcp(group = "Tukey"))
# 查看结果摘要
summary(scheffe_result)
# 查看置信区间
confint(scheffe_result)

# 4. 若方差不齐，使用Welch校正
welch_result <- oneway.test(value ~ group, data = df, var.equal = FALSE)
print(welch_result)

(2 * qf(0.95, 2, 24) * (1 / 12 + 1 / 6) * 0.64)^0.5


1 - pf(108.277, 1, 14)
(19.893)^0.5

19.893 / 0.3024
0.114 * 19.893
qnorm(0.025, 84.397, (65.784)^0.5)

?qnorm

qnorm(0.975, 35.289, (2.268)^0.5)
mu <- 35.289 + 84.397 * 0.15
mu
sd_2 <- (1/16 + (0.15 - 0.125)^2 / 0.3024) * 19.893
sd_2
qnorm(0.975, 47.949, 1.284)


x <- c(76.43, 76.21, 73.58, 69.69, 65.29, 70.83, 82.75, 72.34)
y <- c(73.66, 64.27, 69.34, 71.37, 69.77, 68.12, 67.27, 68.07, 62.61)
bar_x <- mean(x)
bar_y <- mean(y)
var(x)*(length(x)-1)
s <- (var(x)*(length(x)-1) + var(y)*(length(y)-1))^0.5/(length(x)+length(y)-2)^0.5
(bar_x-bar_y)/(s*sqrt(1/length(x)+1/length(y)))
  
qt(0.95, length(x)+length(y)-2)


f_exp <- function(x){exp(-exp(-x))}
f_logis <- function(x){1/(1+exp(-x))}
f_norm <- function(x){pnorm(x)}
f1 <- function(x){1/(1+exp(-x))-pnorm(x)}
(y1 <- f_exp(0))

x1 <- uniroot(f1, c(-2,2))$root
y <- f_norm(x1)

y
uniroot(f_exp,c(-2,2))$root
