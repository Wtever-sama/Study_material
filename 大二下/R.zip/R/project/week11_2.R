setwd("/Users/wtsama/Documents/code/code2/R/data/2assignment/")
library(openxlsx)

# %%
SSE <- read.xlsx("10 年_K线导出_000001_日线数据.xlsx")
head(SSE)
colnames(SSE)

# 简单收益率
# (P_t-P_t-1) / P_t-1
SSE_monday <- read.xlsx("000001_周一.xlsx")
SSE.SimpleReturn_mon <- diff(SSE_monday$收盘价) / SSE_monday$收盘价[-nrow(SSE_monday)]
# 检查数据类型，出去 na
head(SSE.SimpleReturn_mon)
class(SSE.SimpleReturn_mon)
anyNA(SSE.SimpleReturn_mon)
which(complete.cases(SSE.SimpleReturn_mon)==F)
SSE.SimpleReturn_mon <- na.omit(SSE.SimpleReturn_mon)
which(complete.cases(SSE.SimpleReturn_mon)==F)

# 求收益率期望
SSE.expected_return_mon <- mean(SSE.SimpleReturn_mon)
SSE.expected_return_mon  # -0.0001333132

# %%
# 周五
SSE_friday <- read.xlsx("000001_周五.xlsx")
SSE.SimpleReturn_fri <- diff(SSE_friday$收盘价) / SSE_friday$收盘价[-nrow(SSE_friday)]
SSE.SimpleReturn_fri <- na.omit(SSE.SimpleReturn_fri)
SSE.expected_return_fri <- mean(SSE.SimpleReturn_fri)
SSE.expected_return_fri  # -0.0001131746

# %%
# 399001
# 周一
SZSE_mon <- read.xlsx("399001_周一.xlsx")
SZSE.SimpleReturn_mon <- diff(SZSE_mon$收盘价) / SZSE_mon$收盘价[-nrow(SZSE_mon)]
SZSE.SimpleReturn_mon <- na.omit(SZSE.SimpleReturn_mon)
SZSE.expected_return_mon <- mean(SZSE.SimpleReturn_mon)
SZSE.expected_return_mon  # -4.981018e-05

# %%
# 周五
SZSE_fri <- read.xlsx("399001_周五.xlsx")
SZSE.SimpleReturn_fri <- diff(SZSE_fri$收盘价) / SZSE_fri$收盘价[-nrow(SZSE_fri)]
SZSE.SimpleReturn_fri <- na.omit(SZSE.SimpleReturn_fri)
SZSE.expected_return_fri <- mean(SZSE.SimpleReturn_fri)
SZSE.expected_return_fri  # -0.0001742096


# %%
# 399006
# 周一
GEM_mon <- read.xlsx("399006_周一.xlsx")
GEM.SimpleReturn_mon <- diff(GEM_mon$收盘价) / GEM_mon$收盘价[-nrow(GEM_mon)]
GEM.SimpleReturn_mon <- na.omit(GEM.SimpleReturn_mon)
GEM.expected_return_mon <- mean(GEM.SimpleReturn_mon)
GEM.expected_return_mon  # 0.0003730644

# %%
# 周五
GEM_fri <- read.xlsx("399006_周五.xlsx")
GEM.SimpleReturn_fri <- diff(GEM_fri$收盘价) / GEM_fri$收盘价[-nrow(GEM_fri)]
GEM.SimpleReturn_fri <- na.omit(GEM.SimpleReturn_fri)
GEM.expected_return_fri <- mean(GEM.SimpleReturn_fri)
GEM.expected_return_fri  # 1.887546e-06



# %%
# 显著性检验-“红周一”和“红周五”的收益率是否显著不同

# 先对 SSE 分析
# 样本是否符合正态分布
shapiro.test(SSE.SimpleReturn_mon) # W = 0.88236, p-value < 2.2e-16,不符合正态分布
shapiro.test(SSE.SimpleReturn_fri) # W = 0.92968, p-value = 3.129e-14,不符合正态分布

# 转而采用非参数检验替代
# H_0:两组数据（周一和周五的收益率）的中位数（或分布位置）没有差异。
# H_1:两组数据的中位数有差异（即存在“红周一”或“红周五”效应）。
wilcox.test(SSE.SimpleReturn_mon, SSE.SimpleReturn_fri)
# p-value = 0.6516, w = 111838, 没有理由拒绝原假设，不能认为周一和周五的收益率存在显著差异

# 其他同理
wilcox.test(SZSE.SimpleReturn_mon, SZSE.SimpleReturn_fri)
# W = 113526, p-value = 0.9562

wilcox.test(GEM.SimpleReturn_mon, GEM.expected_return_fri)
# W = 223, p-value = 0.9216

# %%
# 单样本 t 检验

t.test(x = SZSE.SimpleReturn_mon, mu = 0, alternative = "greater")
# p-value = 0.9786,认为没有“红色星期一”
t.test(x = SSE.SimpleReturn_mon, mu = 0, alternative = "greater")
# 0.9279
t.test(x = GEM.SimpleReturn_mon, mu = 0, alternative = "greater")
# p-value = 0.8686

# 周五-没有黑色周五
t.test(x = SZSE.SimpleReturn_fri, mu = 0, alternative = "less") #  p=0.4566
t.test(x = SSE.SimpleReturn_fri, mu = 0, alternative = "less")
t.test(x = GEM.SimpleReturn_fri, mu = 0, alternative = "less")

# %%
# 总和三个指数分析
all_data <- rbind(
    data.frame(Index = "SSE", Day = "Monday", Return = SSE.SimpleReturn_mon),
    data.frame(Index = "SSE", Day = "Friday", Return = SSE.SimpleReturn_fri),
    data.frame(Index = "SZSE", Day = "Monday", Return = SZSE.SimpleReturn_mon),
    data.frame(Index = "SZSE", Day = "Friday", Return = SZSE.SimpleReturn_fri),
    data.frame(Index = "GEM", Day = "Monday", Return = GEM.SimpleReturn_mon),
    data.frame(Index = "GEM", Day = "Friday", Return = GEM.SimpleReturn_fri)
)

# 可视化
library(ggplot2)
ggplot(all_data, aes(x = Day, y = Return, fill = Index)) +
  geom_boxplot() +
  labs(title = "Red Monday vs Red Friday Returns across Indices")
save.image("week11_2.png")