setwd('/Users/wtsama/Documents/code/code2/R/project')
# %%
# T1 编写一个代码，考虑如果 y 是一个长度为 n 的向量，x 是一个带有 n 个水平的因子，
# 观察结果是什么。
n <- 3
y <- c(rep(1, n))
class(y)
mode(y)
typeof(y)
x <- factor(c("因子1","因子2","因子3"))
class(x)
mode(x)
typeof(x)

# 设置随机种子以确保结果可重复
set.seed(123)

# 假设 n 是 10
n <- 10

# 生成一个长度为 n 的随机数值向量 y
y <- rnorm(n)

# 生成一个带有 n 个水平的因子 x
# 这里我们假设每个水平只出现一次，即每个水平对应一个唯一的观测值
x <- factor(1:n, levels = 1:n, labels = paste0("Level", 1:n))

# %%
# 查看 y 和 x
print("y 向量:")
print(y)
# %%
print("x 因子:")
print(x)
# %%
# 创建一个数据框来存储 y 和 x
data <- data.frame(y = y, x = x)

# 查看数据框
print("数据框 data:")
print(data)
# %%
# 进行一些基本的统计分析，例如计算每个水平的 y 的平均值
summary_stats <- aggregate(y ~ x, data = data, FUN = mean)

# 查看汇总统计
print("每个水平的 y 的平均值:")
print(summary_stats)

# %%
# ==========================================================================
# T2 分别使用𝑁(0, 1)分布、𝜒2(3)分布，生成1000 × 5两个矩阵、分别记为A与B：
x <- rnorm(1000 * 5) # 生成10个数
print(x)
A <- matrix(x, nrow = 1000, ncol = 5)
y <- rchisq(1000 * 5, df = 3) # 生成 10 个自由度为 3 的卡方分布随机数
print(y)
B <- matrix(y, nrow = 1000, ncol = 5)
### 1）比较矩阵A与矩阵B各列数据的直方图，观察直方图之间的差异
par(mfrow = c(2, 3)) # 设置图形参数的函数，mfrow = c(2, 3) 表示图形窗口分为 2 行
# 3 列 的布局，也就是最多可以放 6 个图
for (i in 1:5) {
  hist(A[, i], # hist() 是绘制直方图的函数，核心是把数据分成多个区间（bin），
       # 统计每个区间内的频数
       main = paste("Column", i), # mat[, i] 取的是矩阵的 第 i 列的所有行
       xlab = paste("Values of Col", i),
       col = "skyblue",
       border = "white")
}
par(mfrow = c(2, 3))
for (i in 1:5){
  hist(B[, i],
       main = paste("col", i),
       xlab = paste("value of col", i),
       col = "grey",
       border = "#a0c5d4")
}
# %%
### 2）将矩阵A与矩阵B按行合并得到矩阵C，观察矩阵C各列数据的直方图，可发现其为一个
# 混合分布的直方图
C <- rbind(A, B)
par(mfrow = c(2, 3))
for (i in 1:5){
  hist(C[, i],
       main = paste("col", i),
       xlab = paste("value of col_c", i),
       col = "purple",
       border = "white")
}


# %%
# ============================================================================
# T3 specialty plan
### 1)
# P出清=1-P(demand_X<进货量 a)
# dnorm(x, mean = 0, sd =1) 概率密度
z <- qnorm(0.95, mean = 0, sd = 1) # 逆 cdf(fi^-1(p))
sigma <- (30000-20000) / z
sigma

p1 <- pnorm(15000, mean = 20000, sd =sigma)
p1
p2 <- pnorm(18000, mean = 20000, sd =sigma)
p2
p3 <- pnorm(24000, mean = 20000, sd =sigma)
p3
p4 <- pnorm(28000, mean = 20000, sd =sigma)
p4
# %%
### 2)
ave <- 20000
w1 <- 15000*(24-16)
w2 <- 18000*(24-16)
w3 <- 24000*(24-16)-(24000-20000)*(16-5)
w4 <- 28000*(24-16)-(28000-20000)*(16-5)
# 15000,profit
w1
# 18000,profit
w2
# 24000,profit
w3
# 28000,profit
w4
# %%
### 3)
# a 是决策量，X 是需求量，求a>X &a<X 的利润，求各自的cdf，求期望的最大值和对应的
# p是需求量的概率密度
p <- function(x) dnorm(x, mean = 20000, sd = sigma)

# x:demand   a:进货量
# 构造利润的期望函数，自变量是a
expected_profit <- function(a) {
  f <- function(x){
    sales <- pmin(x, a)
    leftovers <- pmax(a-x, 0)
    profit <- sales * (24-16) - 11 * leftovers
    profit * dnorm(x, mean = 20000, sd = sigma) # 被积函数：利润*概率密度
  }
  #这里近似将上下界的正负无穷取成“期望+-5sigma”
  integrate(f, lower = 20000 - 5*sigma, upper = 20000 + 5*sigma)$value
}

# ?optimize # 单函数；
# minumum 是取得最小值的自变量的值；objective是最小值（函数值）
# ?optim # 多元函数的优化

optimize(expected_profit, c(20000 - 5*sigma, 20000 + 5*sigma), maximum = T)
# $maximum
# [1] 18780.95
# $objective
# [1] 114823.3
