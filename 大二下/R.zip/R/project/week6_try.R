# 问题3：Specialty 玩具公司订单决策分析

# 参数设定
cost <- 16       # 进货成本/个
price <- 24      # 正常售价/个
clearance <- 5   # 清仓价/个
mu <- 20000      # 需求期望值
sigma <- 5000    # 需求标准差 (95%区间在10000~30000对应约±2σ)

# 1) 计算不同订单量的存货出清概率
order_quantities <- c(15000, 18000, 24000, 28000)
clear_prob <- pnorm(order_quantities, mean = mu, sd = sigma)

cat("问题1：不同订单量的存货出清概率\n")
print(data.frame(订单量 = order_quantities,
                 出清概率 = round(clear_prob, 4)))

# 2) 计算需求恰好为20000时的利润
calculate_profit <- function(order, demand) {
  sales <- min(order, demand)
  leftover <- max(order - demand, 0)
  profit <- sales * (price - cost) - leftover * (cost - clearance)
  return(profit)
}

profits <- sapply(order_quantities, calculate_profit, demand = mu)

cat("\n问题2：需求为20000时的利润\n")
print(data.frame(订单量 = order_quantities,
                 利润 = profits))

# 3) 寻找最优订单量 (扩展分析)
possible_orders <- seq(10000, 30000, by = 1000)

# 计算期望利润函数
expected_profit <- function(order) {
  # 积分计算期望利润
  f <- function(x) {
    sales <- pmin(order, x)
    leftover <- pmax(order - x, 0)
    profit <- sales * (price - cost) - leftover * (cost - clearance)
    profit * dnorm(x, mean = mu, sd = sigma)
  }
  integrate(f, lower = mu - 5*sigma, upper = mu + 5*sigma)$value
  # integrate(f, lower = 0, upper = Inf)$value
}

# 计算所有可能订单的期望利润
expected_profits <- sapply(possible_orders, expected_profit)
expected_profits
optimal_index <- which.max(expected_profits)
optimal_order <- possible_orders[optimal_index]
max_profit <- expected_profits[optimal_index]

cat("\n问题3：最优订单量分析\n")
cat("理论最优订单量:", optimal_order, "\n")
cat("对应期望利润:", round(max_profit, 2), "\n")

# 可视化分析
plot(possible_orders, expected_profits, type = "l",
     xlab = "订单量", ylab = "期望利润",
     main = "订单量-期望利润关系")
abline(v = optimal_order, col = "red", lty = 2)
abline(h = max_profit, col = "blue", lty = 2)
points(order_quantities,
       sapply(order_quantities, expected_profit),
       col = "red", pch = 19)
legend("topright",
       legend = c("理论最优", "管理建议"),
       col = c("red", "red"),
       pch = c(NA, 19), lty = c(2, NA))

